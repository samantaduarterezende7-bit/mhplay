@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -m mh_emulator.app
pause
