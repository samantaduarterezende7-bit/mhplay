@echo off
cd /d "%~dp0"
echo ============================================
echo   MH Play - Instalar Android 13
echo   Feche o MH Play antes de continuar.
echo   O Android 11 continua instalado.
echo ============================================
taskkill /f /fi "WINDOWTITLE eq MH Play" >nul 2>&1
taskkill /f /im qemu-system-x86_64.exe /im emulator.exe >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup13.ps1"
echo.
pause
