@echo off
echo Fechando o MH Play e o Android...
taskkill /f /fi "WINDOWTITLE eq MH Play" >nul 2>&1
taskkill /f /im qemu-system-x86_64.exe /im emulator.exe /im adb.exe /im crashpad_handler.exe >nul 2>&1
echo Pronto. Pode apagar ou atualizar a pasta.
timeout /t 3 >nul
