"""Atualizacao com um clique.

O MH Play le um arquivo version.json hospedado online:
  {"version": "0.4", "zip": "https://.../MHPlay.zip", "notas": "o que mudou"}
Se a versao for maior, baixa o zip e substitui os arquivos do programa.
Nada do Android e mexido: apps, contas e o Free Fire ficam em %LOCALAPPDATA%\\MHEmulator.
"""
import io
import json
import logging
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

VERSION = '0.10'
log = logging.getLogger('mh.update')
SKIP = {'.venv', '__pycache__'}


def _v(s):
    return tuple(int(x) if x.isdigit() else 0 for x in str(s).split('.'))


def check(url):
    import time
    url = f"{url}{'&' if '?' in url else '?'}t={int(time.time())}"  # fura o cache do GitHub
    req = urllib.request.Request(url, headers={'User-Agent': f'MHPlay/{VERSION}', 'Cache-Control': 'no-cache'})
    with urllib.request.urlopen(req, timeout=15) as r:
        info = json.loads(r.read().decode('utf-8'))
    return info if _v(info.get('version', '0')) > _v(VERSION) else None


def apply(info, app_dir):
    app_dir = Path(app_dir)
    req = urllib.request.Request(info['zip'], headers={'User-Agent': f'MHPlay/{VERSION}'})
    with urllib.request.urlopen(req, timeout=300) as r:
        data = r.read()
    z = zipfile.ZipFile(io.BytesIO(data))
    names = [n for n in z.namelist() if not n.endswith('/')]
    # se o zip tem uma pasta raiz (ex: MHEmulator/...), tira ela
    tops = {n.split('/', 1)[0] for n in names}
    strip = len(tops) == 1 and all('/' in n for n in names)
    old_req = (app_dir / 'requirements.txt').read_text(encoding='utf-8', errors='ignore') \
        if (app_dir / 'requirements.txt').exists() else ''
    for n in names:
        rel = n.split('/', 1)[1] if strip else n
        parts = Path(rel).parts
        if not parts or parts[0] in SKIP or '..' in parts:
            continue
        dest = app_dir / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(z.read(n))
    new_req = (app_dir / 'requirements.txt').read_text(encoding='utf-8', errors='ignore')
    if new_req != old_req:
        subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', '-r', str(app_dir / 'requirements.txt')],
                       creationflags=0x08000000)
    log.info('Atualizado para %s', info.get('version'))


def restart(app_dir):
    """Reabre o MH Play 3 s depois (tempo da janela atual fechar e liberar a trava de uma instancia)."""
    exe = Path(sys.executable)
    pyw = exe.with_name('pythonw.exe')
    py = str(pyw if pyw.exists() else exe)
    subprocess.Popen(f'cmd /c timeout /t 3 /nobreak >nul & start "" "{py}" -m mh_emulator.app',
                     cwd=str(app_dir), creationflags=0x08000000)
