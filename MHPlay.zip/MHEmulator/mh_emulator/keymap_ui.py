"""Janela de Mapeamento de teclas + camada que mostra as teclas e o FPS por cima do jogo."""
from PySide6.QtCore import QRect, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import (QCheckBox, QDialog, QDoubleSpinBox, QFileDialog, QFormLayout, QFrame,
                               QHBoxLayout, QHeaderView, QLabel, QPushButton, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget)

from .keymap import load_cfg, short


class KeymapDialog(QDialog):
    def __init__(self, parent, engine, settings, default_path):
        super().__init__(parent)
        self.setWindowTitle('Mapeamento de teclas - MH Play')
        self.resize(620, 640)
        self.engine, self.settings, self.default_path = engine, settings, default_path
        self.layout_obj = engine.layout
        v = QVBoxLayout(self)

        t = QLabel('Mapeamento de teclas'); t.setStyleSheet('font-size:16px;font-weight:600;')
        v.addWidget(t)

        prof = QHBoxLayout()
        self.lbl_prof = QLabel(); self.lbl_prof.setStyleSheet('color:#8A8C99;')
        b_imp = QPushButton('Importar perfil (.cfg)'); b_imp.clicked.connect(self._import)
        b_def = QPushButton('Perfil padrão'); b_def.setStyleSheet('background:#343643;')
        b_def.clicked.connect(lambda: self._load(default_path))
        prof.addWidget(self.lbl_prof, 1); prof.addWidget(b_def); prof.addWidget(b_imp)
        v.addLayout(prof)

        f = QFormLayout()
        self.chk_on = QCheckBox('Mapeamento ativado  (F9 liga/desliga durante o jogo)')
        self.chk_on.setChecked(engine.enabled)
        self.chk_show = QCheckBox('Mostrar teclas na tela')
        self.chk_show.setChecked(settings.get('show_keys', True))
        self.sx = QDoubleSpinBox(); self.sy = QDoubleSpinBox()
        for s in (self.sx, self.sy):
            s.setRange(0.10, 10.0); s.setSingleStep(0.01); s.setDecimals(2)
        self.lbl_aim = QLabel()
        f.addRow(self.chk_on)
        f.addRow(self.chk_show)
        f.addRow('Sensibilidade do mouse X', self.sx)
        f.addRow('Sensibilidade do mouse Y', self.sy)
        f.addRow('Modo mira', self.lbl_aim)
        v.addLayout(f)

        line = QFrame(); line.setFrameShape(QFrame.HLine); line.setStyleSheet('color:#3A3C48;')
        v.addWidget(line)
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(['Tecla', 'Ação', 'Posição na tela'])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setStyleSheet('QTableWidget{background:#1A1B21;gridline-color:#2C2E38;border:none;}'
                                 'QHeaderView::section{background:#23242C;border:none;padding:6px;}')
        v.addWidget(self.table, 1)

        bt = QHBoxLayout(); bt.addStretch(1)
        ok = QPushButton('Salvar'); ok.clicked.connect(self.accept)
        bt.addWidget(ok)
        v.addLayout(bt)
        self._refresh()

    def _refresh(self):
        lay = self.layout_obj
        self.lbl_prof.setText(f'Perfil: {lay.name}' if lay else 'Nenhum perfil carregado')
        pan = lay.pan if lay else None
        self.sx.setValue(float(self.settings.get('sens_x') or (pan.sens if pan else 1.0)))
        self.sy.setValue(float(self.settings.get('sens_y') or (pan.sens * pan.ratio_y if pan else 1.0)))
        self.lbl_aim.setText(f"Tecla {short(pan.toggle)} liga/desliga  •  clique esquerdo atira" if pan else '-')
        rows = []
        if lay and lay.dpad:
            d = lay.dpad
            rows.append((f'{d.up} {d.left} {d.down} {d.right}', 'Andar', f'{d.x:.0f}%, {d.y:.0f}%'))
        if pan:
            rows.append((short(pan.toggle), 'Modo mira (câmera no mouse)', f'{pan.x:.0f}%, {pan.y:.0f}%'))
            rows.append(('Clique esq.', 'Atirar', f'{pan.fire_x:.0f}%, {pan.fire_y:.0f}%'))
        if lay:
            for k, pts in lay.taps.items():
                rows.append((short(k), lay.labels.get(k, 'Toque'), '  |  '.join(f'{x:.0f}%, {y:.0f}%' for x, y in pts)))
            for k, cmds in lay.scripts.items():
                rows.append((short(k), f'Macro ({len(cmds)} passos)', '-'))
        self.table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            for j, val in enumerate(r):
                it = QTableWidgetItem(val)
                if j == 0:
                    it.setFont(QFont('Segoe UI', 10, QFont.Bold))
                self.table.setItem(i, j, it)

    def _load(self, path):
        try:
            self.layout_obj = load_cfg(path)
            self.settings['sens_x'] = None
            self.settings['sens_y'] = None
            self._refresh()
        except Exception as e:
            self.lbl_prof.setText(f'Erro ao ler o perfil: {e}')

    def _import(self):
        p, _ = QFileDialog.getOpenFileName(self, 'Importar perfil de teclas', '', 'Perfil de teclas (*.cfg)')
        if p:
            self._load(p)

    def result_values(self):
        return dict(layout=self.layout_obj, enabled=self.chk_on.isChecked(), show_keys=self.chk_show.isChecked(),
                    sens_x=self.sx.value(), sens_y=self.sy.value())


class Overlay(QWidget):
    """Janela transparente por cima da tela do Android: teclas do mapeamento e FPS. Nao recebe cliques."""

    def __init__(self):
        super().__init__(None, Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnTopHint |
                         Qt.WindowTransparentForInput | Qt.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        self.layout_obj = None
        self.show_keys = True
        self.show_fps = True
        self.fps = None
        self.aim = False
        self.in_game = False

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        W, H = self.width(), self.height()
        if self.show_fps and self.fps is not None:
            p.setFont(QFont('Consolas', 11, QFont.Bold))
            txt = f'FPS {self.fps}'
            p.fillRect(QRect(6, 6, 74, 22), QColor(0, 0, 0, 150))
            c = '#4ADE80' if self.fps >= 50 else ('#FACC15' if self.fps >= 30 else '#F87171')
            p.setPen(QColor(c)); p.drawText(QRect(6, 6, 74, 22), Qt.AlignCenter, txt)
        lay = self.layout_obj
        if not (self.show_keys and lay and self.in_game) or self.aim:
            return  # no modo mira as teclas somem pra nao atrapalhar
        p.setFont(QFont('Segoe UI', 8, QFont.Bold))

        def tag(xp, yp, text):
            x, y = xp * W / 100, yp * H / 100
            w = max(22, p.fontMetrics().horizontalAdvance(text) + 10)
            r = QRect(int(min(max(x - w / 2, 2), W - w - 2)), int(min(max(y - 10, 2), H - 22)), w, 20)
            p.setPen(Qt.NoPen); p.setBrush(QColor(20, 12, 40, 170)); p.drawRoundedRect(r, 10, 10)
            p.setPen(QPen(QColor('#C4B5FD'))); p.drawText(r, Qt.AlignCenter, text)

        if lay.dpad:
            d = lay.dpad
            rx = d.radius
            ry = d.radius * W / H
            p.setPen(QPen(QColor(124, 58, 237, 160), 2)); p.setBrush(Qt.NoBrush)
            p.drawEllipse(QRect(int((d.x - rx) * W / 100), int((d.y - ry) * H / 100), int(2 * rx * W / 100), int(2 * ry * H / 100)))
            tag(d.x, d.y - ry * 0.6, d.up); tag(d.x, d.y + ry * 0.6, d.down)
            tag(d.x - rx * 0.6, d.y, d.left); tag(d.x + rx * 0.6, d.y, d.right)
        if lay.pan:
            tag(lay.pan.x, lay.pan.y, f'Mira {short(lay.pan.toggle)}')
        for k, pts in lay.taps.items():
            for xp, yp in pts:
                tag(xp, yp, short(k))
