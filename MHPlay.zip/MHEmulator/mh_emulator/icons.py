"""Icones vetoriais (SVG desenhados pro MH Play), sem emoji."""
from PySide6.QtCore import QByteArray, QRectF, Qt
from PySide6.QtGui import QIcon, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer

_P = {
    'fullscreen': '<path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/>',
    'vol_up': '<path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a10 10 0 0 1 0 14"/>',
    'vol_down': '<path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/>',
    'keyboard': '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>',
    'crosshair': '<circle cx="12" cy="12" r="8"/><path d="M12 2v5M12 17v5M2 12h5M17 12h5"/><circle cx="12" cy="12" r="1"/>',
    'gamepad': '<rect x="2" y="7" width="20" height="11" rx="5"/><path d="M7 12h4M9 10v4M15.5 11.5h.01M18 13.5h.01"/>',
    'upload': '<path d="M12 18V5M6 11l6-6 6 6M5 21h14"/>',
    'camera': '<path d="M4 7h3l2-3h6l2 3h3a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1z"/><circle cx="12" cy="13" r="4"/>',
    'settings': '<path d="M19.94 9.96 L22.36 10.29 L22.36 13.71 L19.94 14.04 L19.06 16.17 L20.53 18.12 L18.12 20.53 L16.17 19.06 L14.04 19.94 L13.71 22.36 L10.29 22.36 L9.96 19.94 L7.83 19.06 L5.88 20.53 L3.47 18.12 L4.94 16.17 L4.06 14.04 L1.64 13.71 L1.64 10.29 L4.06 9.96 L4.94 7.83 L3.47 5.88 L5.88 3.47 L7.83 4.94 L9.96 4.06 L10.29 1.64 L13.71 1.64 L14.04 4.06 L16.17 4.94 L18.12 3.47 L20.53 5.88 L19.06 7.83 Z"/><circle cx="12" cy="12" r="3.2"/>',
    'back': '<path d="M15 18l-6-6 6-6"/>',
    'home': '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
    'recents': '<rect x="5" y="5" width="14" height="14" rx="2"/>',
    'refresh': '<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>',
    'help': '<circle cx="12" cy="12" r="9"/><path d="M9.2 9a3 3 0 0 1 5.6 1c0 2-2.8 2.6-2.8 4M12 17.5h.01"/>',
    'menu': '<path d="M4 6h16M4 12h16M4 18h16"/>',
    'minimize': '<path d="M5 12h14"/>',
    'maximize': '<rect x="5" y="5" width="14" height="14" rx="1"/>',
    'close': '<path d="M6 6l12 12M18 6 6 18"/>',
    'folder': '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
}

_cache = {}


def icon(name, color='#C9CBD6', size=20):
    key = (name, color, size)
    if key in _cache:
        return _cache[key]
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="{color}" '
           f'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">{_P[name]}</svg>')
    r = QSvgRenderer(QByteArray(svg.encode()))
    ic = QIcon()
    for scale in (1, 2):
        pm = QPixmap(size * scale, size * scale)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        r.render(p, QRectF(0, 0, size * scale, size * scale))
        p.end()
        pm.setDevicePixelRatio(scale)
        ic.addPixmap(pm)
    _cache[key] = ic
    return ic
