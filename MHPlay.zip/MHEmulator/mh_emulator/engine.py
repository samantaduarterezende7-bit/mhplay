"""Motor de mapeamento: transforma teclado/mouse em toques no Android.

Mira: o mouse segura um toque virtual no ponto de "deslocamento" e arrasta com o delta cru
do sensor (Raw Input). Sem aceleracao do Windows e com envio a ~250 Hz, sem acumular erro.
"""
import ctypes
import ctypes.wintypes as wt
import logging
import math
import os
import queue
import threading
import time

from .keymap import parse_script, short, vk_name

log = logging.getLogger('mh.engine')
user32 = ctypes.WinDLL('user32', use_last_error=True)
user32.ClipCursor.argtypes = [ctypes.POINTER(wt.RECT)]
user32.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(wt.DWORD)]

ID_DPAD, ID_PAN, ID_FIRE = 1, 2, 3
POOL = list(range(4, 10))
VK_F9, VK_F11 = 0x78, 0x7A
TICK = 0.004


class GUITHREADINFO(ctypes.Structure):
    _fields_ = [('cbSize', wt.DWORD), ('flags', wt.DWORD), ('hwndActive', wt.HWND), ('hwndFocus', wt.HWND),
                ('hwndCapture', wt.HWND), ('hwndMenuOwner', wt.HWND), ('hwndMoveSize', wt.HWND),
                ('hwndCaret', wt.HWND), ('rcCaret', wt.RECT)]


def focus_pid():
    """Processo da janela que tem o foco do teclado agora."""
    gi = GUITHREADINFO(); gi.cbSize = ctypes.sizeof(GUITHREADINFO)
    if not user32.GetGUIThreadInfo(0, ctypes.byref(gi)) or not gi.hwndFocus:
        return 0
    pid = wt.DWORD()
    user32.GetWindowThreadProcessId(gi.hwndFocus, ctypes.byref(pid))
    return pid.value


def foreground_pid():
    h = user32.GetForegroundWindow()
    pid = wt.DWORD()
    user32.GetWindowThreadProcessId(h, ctypes.byref(pid))
    return pid.value


class Engine:
    def __init__(self, width, height):
        self.W, self.H = width, height
        self.touch = None
        self.layout = None
        self.enabled = True
        self.emu_pid = None            # processo do emulador (quando ele tem o foco, o teclado ja chega sozinho)
        self.in_game = False           # o mapeamento so age com o Free Fire na tela; fora dele o teclado digita normal
        self.aim = False
        self.suspended = False
        self.sens_mult = 0.5           # base interna (pixels por contagem do mouse)
        self.sens_x = None             # sensibilidade X/Y escolhida nas configuracoes (None = a do layout)
        self.sens_y = None
        self.allowed_pids = {os.getpid()}
        self.clip_rect_fn = None       # () -> (l, t, r, b) da area do jogo, em coordenadas de tela
        self.on_status = None          # callback(str)
        self.hotkeys = {}              # vk -> callback (funciona mesmo com mapeamento desligado)
        self.q = queue.Queue()
        self._lock = threading.Lock()
        self._dx = self._dy = 0.0
        self._pool = list(POOL)
        self._pool_lock = threading.Lock()
        self._held = set()
        self._tap_ids = {}
        self._dpad_keys = set()
        self._dpad_down = False
        self._pan_down = False
        self._px = self._py = 0.0
        self._clipped = False
        threading.Thread(target=self._worker, daemon=True, name='mh-engine').start()

    # ---------- util ----------
    def px(self, xp, yp):
        return xp * self.W / 100.0, yp * self.H / 100.0

    def _status(self):
        if self.on_status:
            s = f"Mapeamento: {'ON' if self.enabled else 'OFF'} (F9)   |   Mira: {'ON' if self.aim else 'OFF'}"
            if self.layout and self.layout.pan:
                s += f"  tecla {short(self.layout.pan.toggle)}"
            self.on_status(s)

    def _active(self):
        return foreground_pid() in self.allowed_pids

    def _alloc(self):
        with self._pool_lock:
            return self._pool.pop(0) if self._pool else POOL[-1]

    def _free(self, tid):
        with self._pool_lock:
            if tid not in self._pool and tid in POOL:
                self._pool.append(tid)

    def _send(self, tid, x, y, down):
        if self.touch:
            self.touch.send(tid, max(0, min(self.W - 1, x)), max(0, min(self.H - 1, y)), down)

    def set_layout(self, layout):
        self.q.put(('layout', layout))

    # ---------- chamados pela thread de input (rapido, sem I/O) ----------
    def on_key(self, vk, down):
        if not self._active():
            return False
        if vk in self.hotkeys:
            if down:
                self.hotkeys[vk]()
            return True
        if vk == VK_F9:
            if down:
                self.q.put(('enable', not self.enabled))
            return True
        lay = self.layout
        if not self.enabled or not lay or not self.in_game:
            return self._forward_key(vk, down)
        name = vk_name(vk)
        if not name:
            return False
        if lay.pan and name == lay.pan.toggle:
            if down and name not in self._held:
                self.q.put(('aim', not self.aim))
            self._mark(name, down)
            return True
        if name == 'Escape' and self.aim:
            if down:
                self.q.put(('aim', False))
            return True
        if lay.pan and lay.pan.suspend and name == lay.pan.suspend and self.aim:
            self.q.put(('suspend', down))
            return True
        handled = False
        if lay.dpad and name in (lay.dpad.up, lay.dpad.down, lay.dpad.left, lay.dpad.right):
            self.q.put(('dpad', name, down))
            handled = True
        if name in lay.taps or name in lay.scripts:
            if not (down and name in self._held):  # ignora auto-repeat
                self.q.put(('key', name, down))
            handled = True
        self._mark(name, down)
        return handled or self._forward_key(vk, down)

    def _forward_key(self, vk, down):
        """Digitar no Android: se o foco esta na janela do MH Play (e nao no emulador), repassa a tecla."""
        if not self.touch or vk in (0x5B, 0x5C):  # tecla Windows fica com o Windows
            return False
        if self.emu_pid and focus_pid() == self.emu_pid:
            return False
        self.q.put(('kbd', vk, down))
        return True

    def _mark(self, name, down):
        if down:
            self._held.add(name)
        else:
            self._held.discard(name)

    def on_mouse_button(self, name, down):
        lay = self.layout
        if not (self.enabled and lay and self.in_game and self.aim and not self.suspended and self._active()):
            return False
        if name == 'MouseLButton' and lay.pan and lay.pan.shoot_on_click:
            self.q.put(('fire', down))
        elif name in lay.taps or name in lay.scripts:
            self.q.put(('key', name, down))
        return True  # no modo mira nenhum clique vaza pro Android

    def on_mouse_move(self, dx, dy):
        if self.aim and not self.suspended:
            with self._lock:
                self._dx += dx
                self._dy += dy

    # ---------- worker ----------
    def _worker(self):
        last_clip = 0.0
        while True:
            try:
                op = self.q.get(timeout=TICK)
                self._handle(op)
                while True:
                    self._handle(self.q.get_nowait())
            except queue.Empty:
                pass
            except Exception:
                log.exception('worker')
            self._flush_pan()
            now = time.perf_counter()
            if now - last_clip > 0.25:
                last_clip = now
                self._update_clip()

    def _handle(self, op):
        kind = op[0]
        if kind == 'layout':
            self._release_all()
            self.layout = op[1]
            self._status()
        elif kind == 'enable':
            self.enabled = op[1]
            if not self.enabled:
                self._release_all()
            self._status()
        elif kind == 'aim':
            self._set_aim(op[1])
        elif kind == 'suspend':
            self.suspended = op[1]
            if self.suspended:
                self._pan_up()
                self._unclip()
            else:
                self._pan_start()
        elif kind == 'dpad':
            if op[2]:
                self._dpad_keys.add(op[1])
            else:
                self._dpad_keys.discard(op[1])
            self._update_dpad()
        elif kind == 'key':
            self._key(op[1], op[2])
        elif kind == 'fire':
            p = self.layout.pan
            x, y = self.px(p.fire_x, p.fire_y)
            self._send(ID_FIRE, x, y, op[1])
        elif kind == 'kbd':
            self.touch.key(op[1], op[2])
        elif kind == 'touch':
            _, tid, x, y, down = op
            self._send(tid, x, y, down)
            if not down:
                self._free(tid)

    def _key(self, name, down):
        lay = self.layout
        if name in lay.taps:
            if down:
                ids = []
                for xp, yp in lay.taps[name]:
                    tid = self._alloc()
                    x, y = self.px(xp, yp)
                    self._send(tid, x, y, True)
                    ids.append((tid, x, y))
                self._tap_ids[name] = ids
            else:
                for tid, x, y in self._tap_ids.pop(name, []):
                    self._send(tid, x, y, False)
                    self._free(tid)
        if name in lay.scripts and down:
            steps = parse_script(lay.scripts[name])
            threading.Thread(target=self._run_script, args=(steps,), daemon=True).start()

    def _run_script(self, steps):
        for st in steps:
            if st[0] == 'wait':
                time.sleep(max(st[1], 0.0))
            else:
                tid = self._alloc()
                x, y = self.px(st[1], st[2])
                self.q.put(('touch', tid, x, y, True))
                time.sleep(0.035)
                self.q.put(('touch', tid, x, y, False))

    def _update_dpad(self):
        d = self.layout.dpad
        vx = (d.right in self._dpad_keys) - (d.left in self._dpad_keys)
        vy = (d.down in self._dpad_keys) - (d.up in self._dpad_keys)
        cx, cy = self.px(d.x, d.y)
        if vx == 0 and vy == 0:
            if self._dpad_down:
                self._send(ID_DPAD, cx, cy, False)
                self._dpad_down = False
            return
        r = d.radius * self.W / 100.0
        n = math.hypot(vx, vy)
        tx, ty = cx + vx / n * r, cy + vy / n * r
        if not self._dpad_down:
            self._send(ID_DPAD, cx, cy, True)
            self._dpad_down = True
        self._send(ID_DPAD, tx, ty, True)

    # ---------- mira ----------
    def _set_aim(self, on):
        if not self.layout or not self.layout.pan:
            return
        if on and not self.aim:
            self.aim, self.suspended = True, False
            with self._lock:
                self._dx = self._dy = 0.0
            self._pan_start()
        elif not on and self.aim:
            self.aim = False
            self._pan_up()
            p = self.layout.pan
            fx, fy = self.px(p.fire_x, p.fire_y)
            self._send(ID_FIRE, fx, fy, False)
            self._unclip()
        self._status()

    def _anchor(self):
        p = self.layout.pan
        return self.px(p.x, p.y)

    def _pan_start(self):
        ax, ay = self._anchor()
        self._px, self._py = ax, ay
        self._send(ID_PAN, ax, ay, True)
        self._pan_down = True
        self._update_clip(force=True)

    def _pan_up(self):
        if self._pan_down:
            self._send(ID_PAN, self._px, self._py, False)
            self._pan_down = False

    def _flush_pan(self):
        with self._lock:
            dx, dy = self._dx, self._dy
            self._dx = self._dy = 0.0
        if not (dx or dy) or not self.aim or self.suspended or not self._pan_down:
            return
        p = self.layout.pan
        sx = self.sens_x if self.sens_x else p.sens
        sy = self.sens_y if self.sens_y else p.sens * p.ratio_y
        mx = dx * sx * self.sens_mult
        my = dy * sy * self.sens_mult
        ax, ay = self._anchor()
        rx = max(40.0, min(ax, self.W - ax) * 0.9)
        ry = max(40.0, min(ay, self.H - ay) * 0.9)
        nx, ny = self._px + mx, self._py + my
        if abs(nx - ax) > rx or abs(ny - ay) > ry:
            # chegou na borda: solta e recomeca no centro, mantendo o movimento deste frame
            self._send(ID_PAN, self._px, self._py, False)
            self._send(ID_PAN, ax, ay, True)
            nx, ny = ax + mx, ay + my
        self._px, self._py = nx, ny
        self._send(ID_PAN, nx, ny, True)

    def _update_clip(self, force=False):
        want = self.aim and not self.suspended and self._active() and self.clip_rect_fn
        if want:
            r = self.clip_rect_fn()
            if r:
                l, t, rr, b = r
                rc = wt.RECT(rr - 3, b - 3, rr - 2, b - 2)  # cursor parado no canto, fora do caminho
                user32.ClipCursor(ctypes.byref(rc))
                self._clipped = True
        elif self._clipped or force:
            self._unclip()

    def _unclip(self):
        user32.ClipCursor(None)
        self._clipped = False

    def _release_all(self):
        if self.aim:
            self._set_aim(False)
        for name in list(self._tap_ids):
            self._key(name, False)
        self._dpad_keys.clear()
        if self.layout and self.layout.dpad and self._dpad_down:
            self._update_dpad()
        self._held.clear()
