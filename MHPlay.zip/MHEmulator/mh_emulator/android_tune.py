"""Otimiza o Android pra jogo (roda uma vez, na primeira inicializacao; tudo reversivel).

Sem root: so configuracoes do sistema e apps de fabrica desativados (nao desinstalados).
Play Store, Google Play Services e o Free Fire NUNCA sao tocados.
"""
import logging
from pathlib import Path

log = logging.getLogger('mh.tune')
TUNE_VERSION = 2

SETTINGS = [
    # animacoes do sistema desligadas = menus e troca de apps instantaneos
    'settings put global window_animation_scale 0',
    'settings put global transition_animation_scale 0',
    'settings put global animator_duration_scale 0',
    # tela sempre deitada, sem rotacao automatica
    'settings put system accelerometer_rotation 0',
    'settings put system user_rotation 0',
    # sem Bluetooth, sem localizacao e sem buscas de rede em segundo plano
    'settings put global bluetooth_on 0',
    'settings put global ble_scan_always_enabled 0',
    'settings put global wifi_scan_always_enabled 0',
    'settings put global wifi_networks_available_notification_on 0',
    'settings put secure location_mode 0',
    'settings put global assisted_gps_enabled 0',
    'settings put global nearby_sharing_enabled 0',
    # tela nunca apaga / nao bloqueia
    'settings put system screen_off_timeout 2147483647',
    'settings put global stay_on_while_plugged_in 7',
    'locksettings set-disabled true',
    # economia de bateria desligada (ela reduz o desempenho)
    'settings put global low_power 0',
    'settings put global adaptive_battery_management_enabled 0',
    # sem vibracao, sons de toque, toques visiveis, teclado virtual por cima do jogo
    'settings put system haptic_feedback_enabled 0',
    'settings put system sound_effects_enabled 0',
    'settings put system show_touches 0',
    'settings put system pointer_location 0',
    'settings put secure show_ime_with_hard_keyboard 0',
    # sem relatorios de erro e telemetria rodando por tras
    'settings put global send_action_app_error 0',
    'settings put secure send_action_app_error 0',
    'settings put global auto_time 1',
    # SEM SOM DE NOTIFICACAO e sem pop-up de aviso por cima do jogo (o som do jogo continua normal)
    'settings put global heads_up_notifications_enabled 0',
    "settings put system notification_sound ''",
    "settings put system ringtone ''",
    "settings put system alarm_alert ''",
    'settings put system lockscreen_sounds_enabled 0',
    'settings put global charging_sounds_enabled 0',
    'settings put system dtmf_tone 0',
    'settings put secure notification_badging 0',
    'media volume --stream 5 --set 0', 'media volume --stream 2 --set 0', 'media volume --stream 1 --set 0',
    'cmd media_session volume --stream 5 --set 0', 'cmd media_session volume --stream 2 --set 0',
    'cmd media_session volume --stream 1 --set 0',
]

# apps de fabrica que so gastam memoria num emulador de jogo (desativados, nao apagados)
DISABLE = [
    'com.google.android.youtube', 'com.google.android.apps.youtube.music', 'com.google.android.apps.maps',
    'com.google.android.gm', 'com.google.android.apps.photos', 'com.google.android.calendar',
    'com.google.android.apps.docs', 'com.google.android.videos', 'com.google.android.apps.messaging',
    'com.google.android.dialer', 'com.google.android.contacts', 'com.android.camera2',
    'com.google.android.apps.wellbeing', 'com.google.android.googlequicksearchbox',
    'com.google.android.apps.googleassistant', 'com.google.android.apps.tachyon',
    'com.google.android.apps.subscriptions.red', 'com.google.android.feedback',
    'com.android.dreams.basic', 'com.android.dreams.phototable', 'com.google.android.marvin.talkback',
    'com.android.printspooler', 'com.android.bips', 'com.google.android.printservice.recommendation',
    'com.google.android.apps.restore', 'com.android.emergency', 'com.google.android.projection.gearhead',
    'com.android.stk', 'com.android.cellbroadcastreceiver', 'com.google.android.cellbroadcastreceiver',
    'com.android.bluetoothmidiservice', 'com.android.egg', 'com.android.wallpaper.livepicker',
]


def apply(emu):
    """Aplica tudo num shell so (rapido). Retorna quantos apps foram desativados."""
    try:
        emu.adb('shell', ' ; '.join(c + ' >/dev/null 2>&1' for c in SETTINGS), timeout=60)
    except Exception:
        log.exception('settings')
    installed = set()
    try:
        out = emu.adb('shell', 'pm', 'list', 'packages', '-e', timeout=30)
        installed = {l.split(':', 1)[1].strip() for l in out.splitlines() if l.startswith('package:')}
    except Exception:
        log.exception('pm list')
    targets = [p for p in DISABLE if p in installed]
    if targets:
        try:
            emu.adb('shell', ' ; '.join(f'pm disable-user --user 0 {p} >/dev/null 2>&1' for p in targets), timeout=120)
        except Exception:
            log.exception('pm disable')
    try:
        emu.adb('shell', 'svc bluetooth disable >/dev/null 2>&1; am kill-all', timeout=20)
    except Exception:
        pass
    log.info('Android otimizado: %d apps de fabrica desativados', len(targets))
    return len(targets)


def push_wallpaper(emu, image: Path):
    """Coloca o plano de fundo MH Play na Galeria e abre a tela de 'Definir como plano de fundo'."""
    dest = '/sdcard/Pictures/MHPlay_fundo.png'
    emu.adb('push', str(image), dest, timeout=60)
    emu.adb('shell', f'am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://{dest}', timeout=20)
    out = emu.adb('shell', f'am start -a android.intent.action.ATTACH_DATA -c android.intent.category.DEFAULT '
                           f'-t image/png -d file://{dest}', timeout=20)
    return 'Error' not in out
