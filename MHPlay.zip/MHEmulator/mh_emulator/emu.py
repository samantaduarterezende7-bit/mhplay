"""Controle do emulador Android (processo, janela, adb, config do AVD)."""
import ctypes
import ctypes.wintypes as wt
import json
import logging
import os
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path(os.environ.get('LOCALAPPDATA', '.')) / 'MHEmulator'
SDK = ROOT / 'sdk'
AVD_HOME = ROOT / 'avd'
AVD = 'MH_FF'
EMU = SDK / 'emulator' / 'emulator.exe'
ADB = SDK / 'platform-tools' / 'adb.exe'
SERIAL = 'emulator-5554'
GRPC_PORT = 8554
SETTINGS_FILE = ROOT / 'settings.json'
LOG_DIR = ROOT / 'logs'
CREATE_NO_WINDOW = 0x08000000
FF_PACKAGE = 'com.dts.freefireth'

log = logging.getLogger('mh.emu')

DEFAULT_SETTINGS = {
    'keymap': '',
    'sens_mult': 0.5,
    'embed': True,
    'cold_boot': False,
    'gpu': 'host',          # host = placa de video (NVIDIA) | auto | swiftshader_indirect = sem GPU
    'gpu_pref': True,       # forca o Windows a usar a GPU dedicada no emulador
    'show_fps': True,
    'show_keys': True,
    'ram_tuned': False,
}

GPU_MODES = [('host', 'GPU dedicada (NVIDIA) - recomendado'), ('auto', 'Automático'),
             ('swiftshader_indirect', 'Software (sem GPU, só se der erro)')]


def load_settings():
    s = dict(DEFAULT_SETTINGS)
    try:
        s.update(json.loads(SETTINGS_FILE.read_text(encoding='utf-8')))
    except Exception:
        pass
    return s


def save_settings(s):
    ROOT.mkdir(parents=True, exist_ok=True)
    SETTINGS_FILE.write_text(json.dumps(s, indent=2), encoding='utf-8')


def apply_data_dir(settings):
    """Usa a pasta escolhida pelo usuario para os dados do Android (ex: D:\\MHPlay)."""
    global AVD_HOME
    if settings.get('avd_home') and Path(settings['avd_home'], f'{AVD}.avd').exists():
        AVD_HOME = Path(settings['avd_home'])


def move_data_dir(dest_root, log_cb=None):
    """Move a pasta do Android (apps, conta, Free Fire) para outro disco. Emulador precisa estar desligado."""
    global AVD_HOME
    dest = Path(dest_root)
    dest.mkdir(parents=True, exist_ok=True)
    src_avd = AVD_HOME / f'{AVD}.avd'
    dst_avd = dest / f'{AVD}.avd'
    if log_cb:
        log_cb(f'Movendo os dados do Android para {dest} (só desta vez, pode levar alguns minutos)…')
    r = subprocess.run(['robocopy', str(src_avd), str(dst_avd), '/MOVE', '/E', '/R:2', '/W:2', '/NP', '/NFL', '/NDL'],
                       capture_output=True, creationflags=CREATE_NO_WINDOW)
    if r.returncode >= 8:
        raise RuntimeError(f'robocopy falhou (codigo {r.returncode})')
    ini_src = AVD_HOME / f'{AVD}.ini'
    target = 'android-30'
    try:
        for line in ini_src.read_text(encoding='utf-8', errors='ignore').splitlines():
            if line.startswith('target='):
                target = line.split('=', 1)[1].strip()
        ini_src.unlink()
    except Exception:
        pass
    (dest / f'{AVD}.ini').write_text(f'avd.ini.encoding=UTF-8\npath={dst_avd}\npath.rel=avd\\{AVD}.avd\ntarget={target}\n',
                                     encoding='utf-8')
    AVD_HOME = dest
    return dest


def avd_config_path():
    return AVD_HOME / f'{AVD}.avd' / 'config.ini'


def read_avd_config():
    cfg = {}
    try:
        for line in avd_config_path().read_text(encoding='utf-8', errors='ignore').splitlines():
            if '=' in line:
                k, v = line.split('=', 1)
                cfg[k.strip()] = v.strip()
    except FileNotFoundError:
        pass
    return cfg


def write_avd_config(updates):
    p = avd_config_path()
    lines = p.read_text(encoding='utf-8', errors='ignore').splitlines()
    done = set()
    for i, line in enumerate(lines):
        if '=' in line:
            k = line.split('=', 1)[0].strip()
            if k in updates:
                lines[i] = f'{k}={updates[k]}'
                done.add(k)
    for k, v in updates.items():
        if k not in done:
            lines.append(f'{k}={v}')
    p.write_text('\n'.join(lines) + '\n', encoding='ascii')


def _env():
    e = os.environ.copy()
    e['ANDROID_SDK_ROOT'] = str(SDK)
    e['ANDROID_HOME'] = str(SDK)
    e['ANDROID_AVD_HOME'] = str(AVD_HOME)
    return e


# ---------------- Win32 ----------------
user32 = ctypes.WinDLL('user32', use_last_error=True) if os.name == 'nt' else None
EnumWindowsProc = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
GWL_STYLE = -16
WS_CHILD = 0x40000000
WS_POPUP = 0x80000000
WS_CAPTION = 0x00C00000
WS_THICKFRAME = 0x00040000
WS_SYSMENU = 0x00080000
WS_MINIMIZEBOX = 0x00020000
WS_MAXIMIZEBOX = 0x00010000
SW_HIDE = 0
SW_SHOW = 5

if user32:
    user32.SetWindowLongPtrW.argtypes = [wt.HWND, ctypes.c_int, ctypes.c_ssize_t]
    user32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
    user32.GetWindowLongPtrW.argtypes = [wt.HWND, ctypes.c_int]
    user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
    user32.SetParent.argtypes = [wt.HWND, wt.HWND]
    user32.SetParent.restype = wt.HWND
    user32.MoveWindow.argtypes = [wt.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wt.BOOL]
    user32.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(wt.DWORD)]
    user32.IsWindow.argtypes = [wt.HWND]


def window_pid(hwnd):
    pid = wt.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return pid.value


def _window_text(hwnd):
    n = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(n + 1)
    user32.GetWindowTextW(hwnd, buf, n + 1)
    return buf.value


def _top_windows():
    out = []

    def cb(hwnd, _):
        out.append(hwnd)
        return True
    user32.EnumWindows(EnumWindowsProc(cb), 0)
    return out


def kill_leftovers():
    """Mata todo processo que roda de dentro do SDK do MH Play (emulador, qemu, adb, crashpad)."""
    try:
        subprocess.run([str(ADB), 'kill-server'], capture_output=True, timeout=5,
                       creationflags=CREATE_NO_WINDOW, env=_env())
    except Exception:
        pass
    try:
        import psutil
        root = str(SDK).lower()
        for p in psutil.process_iter(['exe']):
            exe = (p.info.get('exe') or '').lower()
            if exe.startswith(root):
                try:
                    p.kill()
                except Exception:
                    pass
    except ImportError:
        subprocess.run(['taskkill', '/f', '/im', 'qemu-system-x86_64.exe', '/im', 'emulator.exe',
                        '/im', 'adb.exe', '/im', 'crashpad_handler.exe'], capture_output=True,
                       creationflags=CREATE_NO_WINDOW)


class Emulator:
    def __init__(self):
        self.proc = None
        self.hwnd = None
        self.pid = None
        self._logf = None

    # ---- processo ----
    def installed(self):
        return EMU.exists() and avd_config_path().exists()

    def reset_window_prefs(self):
        """O emulador lembra posicao/escala da janela; zera isso pra ela encaixar certinho dentro do MH Play."""
        p = AVD_HOME / f'{AVD}.avd' / 'emulator-user.ini'
        try:
            lines = p.read_text(encoding='utf-8', errors='ignore').splitlines() if p.exists() else []
            keep = [l for l in lines if l.split('=', 1)[0].strip() not in ('window.x', 'window.y', 'window.scale')]
            p.write_text('\n'.join(keep + ['window.x = 0', 'window.y = 0']) + '\n', encoding='utf-8')
        except Exception:
            log.exception('emulator-user.ini')

    def tune_for_speed(self, settings):
        """Deixa o inicio rapido: o Android salva o estado ao fechar (snapshot) e volta em segundos.
        O snapshot ocupa o tamanho da RAM no disco, entao 4 GB e o ponto ideal (o Free Fire roda liso com isso)."""
        msg = ''
        cfg = read_avd_config()
        if not settings.get('cold_fix'):
            settings['cold_boot'] = False   # "ligar do zero sempre" deixava tudo lento
            settings['cold_fix'] = True
            save_settings(settings)
        if not settings.get('ram_tuned'):
            write_avd_config({'fastboot.forceFastBoot': 'yes', 'fastboot.forceColdBoot': 'no'})
            settings['ram_tuned'] = True
            save_settings(settings)
        ram = int(read_avd_config().get('hw.ramSize', 4096))
        free_mb = shutil.disk_usage(str(AVD_HOME)).free / 1024 / 1024
        if free_mb < ram + 1024:
            msg = (f'Pouco espaço no disco ({free_mb / 1024:.1f} GB livres) pra salvar o estado do Android: ele liga do zero. '
                   'Dica: Configurações > Dados do Android > Mudar local (ex: disco D:).')
        return msg

    def set_gpu_preference(self):
        """Windows > Configuracoes de graficos: 'Alto desempenho' para o emulador (usa a NVIDIA)."""
        try:
            import winreg
            k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r'Software\Microsoft\DirectX\UserGpuPreferences')
            for exe in (SDK / 'emulator' / 'qemu' / 'windows-x86_64' / 'qemu-system-x86_64.exe', EMU):
                winreg.SetValueEx(k, str(exe), 0, winreg.REG_SZ, 'GpuPreference=2;')
            winreg.CloseKey(k)
        except Exception:
            log.exception('gpu pref')

    def foreground_package(self):
        """App que esta na tela do Android agora (ex: com.dts.freefireth)."""
        out = self.adb('shell', 'dumpsys', 'window', '|', 'grep', '-m1', 'mCurrentFocus', timeout=3)
        import re
        m = re.search(r'\s([a-zA-Z0-9_.]+)/', out)
        return m.group(1) if m else ''

    def frame_count(self):
        """Mantido por compatibilidade (bloqueado no Android 11 sem root)."""
        return None

    def game_fps(self):
        """FPS real do jogo: le os horarios dos ultimos quadros da camada do Free Fire no SurfaceFlinger."""
        if not getattr(self, '_ff_layer', None):
            out = self.adb('shell', 'dumpsys', 'SurfaceFlinger', '--list', timeout=4)
            layers = [l.strip() for l in out.splitlines() if FF_PACKAGE in l]
            # a camada que desenha o jogo e o SurfaceView (Unity); senao, a janela principal
            pick = [l for l in layers if 'SurfaceView' in l and 'Background' not in l] or layers
            if not pick:
                return None
            self._ff_layer = pick[-1]
        out = self.adb('shell', 'dumpsys', 'SurfaceFlinger', '--latency', f"'{self._ff_layer}'", timeout=4)
        rows = out.splitlines()[1:]
        ts = []
        for r in rows:
            parts = r.split()
            if len(parts) == 3:
                t = int(parts[1])
                if 0 < t < 2 ** 62:
                    ts.append(t)
        if len(ts) < 2:
            self._ff_layer = None  # camada mudou (ex: saiu do jogo); procura de novo
            return None
        last = max(ts)
        return sum(1 for t in ts if t > last - 1_000_000_000)

    def start(self, cold=False, gpu='host', locale=None):
        kill_leftovers()  # sobra de uma sessao anterior que travou
        self.reset_window_prefs()
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        self._logf = open(LOG_DIR / 'emulator.log', 'w', encoding='utf-8', errors='ignore')
        args = [str(EMU), '-avd', AVD, '-grpc', str(GRPC_PORT), '-gpu', gpu or 'host', '-no-metrics',
                '-no-boot-anim', '-netdelay', 'none', '-netspeed', 'full']
        if cold:
            args.append('-no-snapshot-load')
        if locale:
            args += ['-change-locale', locale]
        log.info('Iniciando: %s', ' '.join(args))
        self.proc = subprocess.Popen(args, env=_env(), stdout=self._logf, stderr=subprocess.STDOUT,
                                     creationflags=CREATE_NO_WINDOW)

    def ensure_disk(self):
        """Ajusta a memoria interna do Android ao espaco livre no disco. Retorna (ok, mensagem)."""
        avd_dir = AVD_HOME / f'{AVD}.avd'
        if (avd_dir / 'userdata-qemu.img').exists():
            # NUNCA mexer no tamanho da memoria interna depois que o Android existe:
            # o emulador recria a particao e apaga apps, login e jogos.
            return True, ''
        free_mb = shutil.disk_usage(str(avd_dir)).free / 1024 / 1024
        raw = read_avd_config().get('disk.dataPartition.size', '6G').upper().strip()
        try:
            size_mb = float(raw[:-1]) * (1024 if raw.endswith('G') else 1) if raw[-1] in 'GM' else float(raw) / 1048576
        except ValueError:
            size_mb = 6144
        if size_mb * 1.2 + 512 <= free_mb:
            return True, ''
        new_gb = int((free_mb - 1024) / 1.2 / 1024)
        if new_gb < 4:
            return False, (f'Pouco espaço no disco C: (livre: {free_mb / 1024:.1f} GB). '
                           'O Android precisa de pelo menos 6 GB livres. Libere espaço e abra de novo.')
        new_gb = min(new_gb, 16)
        write_avd_config({'disk.dataPartition.size': f'{new_gb}G'})
        log.info('Memoria interna ajustada para %d GB (livre: %.0f MB)', new_gb, free_mb)
        return True, f'Memória interna ajustada para {new_gb} GB (pouco espaço livre no disco).'

    def last_error(self):
        try:
            lines = (LOG_DIR / 'emulator.log').read_text(encoding='utf-8', errors='ignore').splitlines()
        except Exception:
            return ''
        fatal = [l for l in lines if 'FATAL' in l or 'ERROR' in l]
        return (fatal or lines[-1:] or [''])[-1].split('|', 1)[-1].strip()

    def running(self):
        return self.proc is not None and self.proc.poll() is None

    def adb(self, *a, timeout=30, binary=False):
        r = subprocess.run([str(ADB), '-s', SERIAL, *a], capture_output=True, timeout=timeout,
                           creationflags=CREATE_NO_WINDOW, env=_env())
        return r.stdout if binary else r.stdout.decode('utf-8', 'ignore').strip()

    def wait_boot(self, timeout=300):
        t0 = time.time()
        subprocess.run([str(ADB), 'start-server'], capture_output=True, creationflags=CREATE_NO_WINDOW, env=_env())
        while time.time() - t0 < timeout:
            if not self.running():
                return False
            try:
                if self.adb('shell', 'getprop', 'sys.boot_completed', timeout=5) == '1':
                    return True
            except Exception:
                pass
            time.sleep(1.5)
        return False

    def stop(self):
        """Desliga o Android e garante que nenhum processo fica preso segurando a pasta."""
        try:
            self.adb('emu', 'kill', timeout=8)
        except Exception:
            pass
        if self.proc:
            try:
                # espera o Android salvar o estado (snapshot): e isso que faz o proximo inicio levar segundos
                self.proc.wait(45)
            except Exception:
                pass
        kill_leftovers()

    # ---- janela ----
    def find_window(self, timeout=90):
        t0 = time.time()
        while time.time() - t0 < timeout:
            if not self.running():
                return None
            for h in _top_windows():
                if user32.IsWindowVisible(h):
                    t = _window_text(h)
                    if t.startswith('Android Emulator') and AVD in t:
                        self.hwnd = h
                        self.pid = window_pid(h)
                        return h
            time.sleep(0.5)
        return None

    def hide_extra_windows(self):
        """Esconde a barra lateral nativa do emulador (fica no mesmo processo)."""
        if not self.pid:
            return
        for h in _top_windows():
            if h != self.hwnd and user32.IsWindowVisible(h) and window_pid(h) == self.pid:
                user32.ShowWindow(h, SW_HIDE)

    def embed(self, parent_hwnd):
        h = self.hwnd
        style = user32.GetWindowLongPtrW(h, GWL_STYLE)
        style &= ~(WS_POPUP | WS_CAPTION | WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX)
        style |= WS_CHILD
        user32.SetWindowLongPtrW(h, GWL_STYLE, style)
        user32.SetParent(h, parent_hwnd)
        user32.ShowWindow(h, SW_SHOW)

    def resize(self, x, y, w, h):
        """Move a tela do Android so se mudou (evita briga de tamanho = tela piscando)."""
        if not (self.hwnd and user32.IsWindow(self.hwnd)):
            return
        if getattr(self, '_last_rect', None) == (x, y, w, h):
            return
        self._last_rect = (x, y, w, h)
        user32.MoveWindow(self.hwnd, x, y, w, h, True)

    # ---- atalhos android ----
    def key(self, code):
        self.adb('shell', 'input', 'keyevent', str(code), timeout=10)

    def install_apk(self, path):
        return self.adb('install', '-r', '-g', path, timeout=600)

    def screenshot(self, dest):
        data = self.adb('exec-out', 'screencap', '-p', timeout=20, binary=True)
        Path(dest).write_bytes(data)

    def open_freefire(self):
        return self.adb('shell', 'monkey', '-p', FF_PACKAGE, '-c', 'android.intent.category.LAUNCHER', '1')
