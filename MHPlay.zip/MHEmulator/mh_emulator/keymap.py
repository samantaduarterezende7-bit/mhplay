"""Layout de teclas. Le o formato .cfg de mapeamento (o mesmo que voce exporta do App Player),
para reaproveitar o seu layout do Free Fire."""
import json
from dataclasses import dataclass, field

# VK do Windows -> nome de tecla usado nos .cfg
_VK = {0x10: 'Shift', 0xA0: 'Shift', 0xA1: 'Shift', 0x11: 'Ctrl', 0xA2: 'Ctrl', 0xA3: 'Ctrl',
       0x12: 'Alt', 0xA4: 'Alt', 0xA5: 'Alt', 0x20: 'Space', 0x09: 'Tab', 0x1B: 'Escape',
       0x0D: 'Return', 0x08: 'Back', 0x14: 'Capital', 0xC0: 'Oem3',
       0x25: 'Left', 0x26: 'Up', 0x27: 'Right', 0x28: 'Down',
       0xBA: 'Oem1', 0xBB: 'OemPlus', 0xBC: 'OemComma', 0xBD: 'OemMinus', 0xBE: 'OemPeriod',
       0xBF: 'Oem2', 0xDB: 'Oem4', 0xDC: 'Oem5', 0xDD: 'Oem6', 0xDE: 'Oem7', 0xC1: 'AbntC1', 0xC2: 'AbntC2'}
for _i in range(26):
    _VK[0x41 + _i] = chr(0x41 + _i)
for _i in range(10):
    _VK[0x30 + _i] = str(_i)
    _VK[0x60 + _i] = f'NumPad{_i}'
for _i in range(12):
    _VK[0x70 + _i] = f'F{_i + 1}'

_ALIASES = {'LeftShift': 'Shift', 'RightShift': 'Shift', 'LeftCtrl': 'Ctrl', 'RightCtrl': 'Ctrl',
            'LeftAlt': 'Alt', 'RightAlt': 'Alt', 'Enter': 'Return', 'CapsLock': 'Capital',
            'OemTilde': 'Oem3', 'Esc': 'Escape'}


def vk_name(vk):
    return _VK.get(vk)


def norm_key(k):
    k = (k or '').strip()
    if not k or '+' in k or k.startswith('Gamepad'):
        return ''
    if len(k) == 2 and k[0] == 'D' and k[1].isdigit():
        k = k[1]
    k = _ALIASES.get(k, k)
    return k.upper() if len(k) == 1 else k


@dataclass
class Dpad:
    x: float
    y: float
    radius: float           # % da largura
    up: str = 'W'
    down: str = 'S'
    left: str = 'A'
    right: str = 'D'


@dataclass
class Pan:
    x: float
    y: float
    fire_x: float
    fire_y: float
    sens: float = 1.0
    ratio_y: float = 1.0
    toggle: str = 'Oem3'
    suspend: str = ''
    shoot_on_click: bool = True


@dataclass
class Layout:
    name: str = 'Sem nome'
    dpad: Dpad = None
    pan: Pan = None
    taps: dict = field(default_factory=dict)     # tecla -> [(x%, y%), ...]
    scripts: dict = field(default_factory=dict)  # tecla -> [comandos]
    labels: dict = field(default_factory=dict)   # tecla -> nome da acao (pt-BR)
    path: str = ''

    def mapped_keys(self):
        ks = set(self.taps) | set(self.scripts)
        if self.dpad:
            ks |= {self.dpad.up, self.dpad.down, self.dpad.left, self.dpad.right}
        return ks


def load_cfg(path):
    with open(path, encoding='utf-8-sig') as f:
        data = json.load(f)
    schemes = data.get('ControlSchemes') or []
    if not schemes:
        raise ValueError('Arquivo sem esquema de controle')
    sch = next((s for s in schemes if s.get('Selected')), schemes[0])
    lay = Layout(name=sch.get('Name', 'Layout'), path=str(path))
    pt = (data.get('Strings') or {}).get('pt-BR', {})
    for c in sch.get('GameControls', []):
        t = c.get('Type')
        if t == 'Dpad':
            lay.dpad = Dpad(c['X'], c['Y'], c.get('XRadius', 10.0) or 10.0,
                            norm_key(c.get('KeyUp')) or 'W', norm_key(c.get('KeyDown')) or 'S',
                            norm_key(c.get('KeyLeft')) or 'A', norm_key(c.get('KeyRight')) or 'D')
        elif t == 'Pan':
            lay.pan = Pan(c['X'], c['Y'], c.get('LButtonX', c['X']), c.get('LButtonY', c['Y']),
                          float(c.get('Sensitivity', 1.0)), float(c.get('SensitivityRatioY', 1.0)),
                          norm_key(c.get('KeyStartStop')) or 'Oem3', norm_key(c.get('KeySuspend')),
                          bool(c.get('IsShootOnClickEnabled', True)))
        elif t == 'Tap':
            k = norm_key(c.get('Key'))
            if k:
                lay.taps.setdefault(k, []).append((c['X'], c['Y']))
                g = (c.get('Guidance') or {}).get('Key', '')
                if g and k not in lay.labels:
                    lay.labels[k] = pt.get(g, g)
        elif t == 'Script':
            k = norm_key(c.get('Key'))
            if k:
                lay.scripts[k] = [s for s in c.get('Commands', []) if s.strip()]
                lay.labels.setdefault(k, 'Macro')
    # o botao de tiro do modo mira nao pode ser tambem um toque comum
    lay.taps.pop('MouseLButton', None)
    # tecla de "suspender mira" que tambem e um botao do jogo (ex: X = curar) faz a mira pular: o botao vence
    if lay.pan and lay.pan.suspend and (lay.pan.suspend in lay.taps or lay.pan.suspend in lay.scripts):
        lay.pan.suspend = ''
    return lay


def parse_script(cmds):
    """Converte 'TAP x y' / 'WAIT ms' em lista de ('tap', x, y) / ('wait', segundos)."""
    out = []
    for raw in cmds:
        p = raw.split()
        if not p:
            continue
        op = p[0].lower()
        try:
            if op == 'tap' and len(p) >= 3:
                out.append(('tap', float(p[1]), float(p[2])))
            elif op == 'wait' and len(p) >= 2:
                out.append(('wait', float(p[1]) / 1000.0))
        except ValueError:
            continue
    return out


SHORT = {'Oem3': "'", 'MouseLButton': 'Clique esq.', 'MouseRButton': 'Clique dir.', 'MouseMButton': 'Clique meio',
         'MouseXButton1': 'Mouse X1', 'MouseXButton2': 'Mouse X2', 'Space': 'Espaço', 'Return': 'Enter',
         'Capital': 'Caps', 'Escape': 'Esc', 'Right': '→', 'Left': '←', 'Up': '↑', 'Down': '↓'}


def short(k):
    return SHORT.get(k, k)
