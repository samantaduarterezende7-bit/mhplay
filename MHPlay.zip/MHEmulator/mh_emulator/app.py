"""MH Play - janela principal."""
import logging
import os
import shutil
import sys
import threading
import time
from pathlib import Path

from PySide6.QtCore import QObject, QPoint, QRect, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QPushButton,
                               QDoubleSpinBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel,
                               QMainWindow, QMessageBox, QSpinBox, QToolButton, QVBoxLayout, QWidget)

from . import emu, icons, updater
from .keymap_ui import KeymapDialog, Overlay
from .engine import VK_F11, Engine
from .keymap import load_cfg

APP_DIR = Path(__file__).resolve().parent.parent
DEFAULT_KEYMAP = APP_DIR / 'keymaps' / 'freefire.cfg'
ASSETS = APP_DIR / 'assets'
UPDATE_URL = 'https://raw.githubusercontent.com/samantaduarterezende7-bit/mhplay/main/version.json'

emu.LOG_DIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(name)s %(levelname)s %(message)s',
                    handlers=[logging.FileHandler(emu.LOG_DIR / 'mh.log', encoding='utf-8'),
                              logging.StreamHandler(sys.stdout)])
log = logging.getLogger('mh.app')

STYLE = """
* { font-family: 'Segoe UI'; color: #E6E6EA; }
QMainWindow, #root { background: #1E1F26; }
#topbar { background: #23242C; }
#sidebar { background: #23242C; }
#screen { background: #000000; }
#title { font-size: 13px; font-weight: 600; }
#sub { font-size: 10px; color: #8A8C99; }
QToolButton { background: transparent; border: none; border-radius: 6px; padding: 6px; font-size: 15px; }
QToolButton:hover { background: #343643; }
QToolButton#close:hover { background: #E81123; }
#logo { background: transparent; }
QToolButton:checked { background: #2A1A4A; color: #22D3EE; }
#status { color: #8A8C99; font-size: 11px; padding: 3px 10px; background: #18191F; }
#placeholder { color: #8A8C99; font-size: 16px; }
QDialog { background: #23242C; }
QSpinBox, QDoubleSpinBox, QComboBox { background: #1A1B21; border: 1px solid #3A3C48; border-radius: 4px; padding: 4px; }
QPushButton { background: #7C3AED; border: none; border-radius: 4px; padding: 6px 14px; }
"""


class Bridge(QObject):
    status = Signal(str)
    window_found = Signal()
    booted = Signal(bool, str)
    toast = Signal(str)
    fullscreen = Signal()
    update_found = Signal(dict, bool)
    fps = Signal(object)
    game = Signal(bool)


def tb(text, tip, slot=None, checkable=False, name=None, ic=None, under=False):
    b = QToolButton()
    if ic:
        b.setIcon(icons.icon(ic))
        b.setIconSize(QSize(20, 20))
    b.setText(text)
    if ic and text:
        b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon if under else Qt.ToolButtonTextBesideIcon)
    b.setToolTip(tip)
    b.setCheckable(checkable)
    b.setCursor(Qt.PointingHandCursor)
    if name:
        b.setObjectName(name)
    if slot:
        b.clicked.connect(slot)
    return b


class SettingsDialog(QDialog):
    def __init__(self, parent, settings):
        super().__init__(parent)
        self.setWindowTitle('Configurações - MH Play')
        self.setMinimumWidth(460)
        self.settings = settings
        cfg = emu.read_avd_config()
        f = QFormLayout(self)

        def sec(t):
            l = QLabel(t); l.setStyleSheet('font-weight:600;color:#C4B5FD;margin-top:8px;')
            f.addRow(l)

        sec('Desempenho')
        self.cores = QSpinBox(); self.cores.setRange(2, 8); self.cores.setValue(int(cfg.get('hw.cpu.ncore', 6)))
        self.ram = QComboBox()
        for v, n in ((4096, '4 GB'), (6144, '6 GB'), (8192, '8 GB  (recomendado pro Free Fire)'), (12288, '12 GB'), (0, 'Personalizado')):
            self.ram.addItem(n, v)
        self.ram_val = QSpinBox(); self.ram_val.setRange(2048, 16384); self.ram_val.setSingleStep(512); self.ram_val.setSuffix(' MB')
        cur_ram = int(cfg.get('hw.ramSize', 4096))
        self.ram_val.setValue(cur_ram)
        i = self.ram.findData(cur_ram)
        self.ram.setCurrentIndex(i if i >= 0 else 4)
        self.ram_val.setEnabled(self.ram.currentData() == 0)
        self.ram.currentIndexChanged.connect(lambda _: self.ram_val.setEnabled(self.ram.currentData() == 0))
        ram_row = QHBoxLayout(); ram_row.addWidget(self.ram, 1); ram_row.addWidget(self.ram_val)
        f.addRow('Núcleos de CPU', self.cores)
        f.addRow('Memória', ram_row)

        sec('Gráficos')
        self.gpu = QComboBox()
        for k, label in emu.GPU_MODES:
            self.gpu.addItem(label, k)
        self.gpu.setCurrentIndex(max(0, self.gpu.findData(settings.get('gpu', 'host'))))
        self.gpu_pref = QCheckBox('Forçar o Windows a usar a placa de vídeo dedicada'); self.gpu_pref.setChecked(settings.get('gpu_pref', True))
        self.fps = QCheckBox('Mostrar FPS na tela'); self.fps.setChecked(settings.get('show_fps', True))
        self.fpsmax = QComboBox()
        for v in (60, 90, 120, 144, 240):
            self.fpsmax.addItem(f'{v} FPS' + ('  (padrão)' if v == 60 else ''), v)
        i = self.fpsmax.findData(int(cfg.get('hw.lcd.vsync', 60)))
        self.fpsmax.setCurrentIndex(i if i >= 0 else 0)
        f.addRow('Renderização', self.gpu)
        f.addRow('FPS máximo', self.fpsmax)
        f.addRow(self.gpu_pref)
        f.addRow(self.fps)

        sec('Tela')
        self.res = QComboBox()
        for w, h in ((1280, 720), (1600, 900), (1920, 1080)):
            self.res.addItem(f'{w} x {h}', f'{w}x{h}')
        cur = f"{int(cfg.get('hw.lcd.width', 1600))}x{int(cfg.get('hw.lcd.height', 900))}"
        i = self.res.findData(cur)
        self.res.setCurrentIndex(i if i >= 0 else 1)
        self.dpi_sel = QComboBox()
        for d, n in ((160, '160 DPI (Baixo)'), (240, '240 DPI (Médio)'), (320, '320 DPI (Alto)'), (0, 'Personalizado')):
            self.dpi_sel.addItem(n, d)
        self.dpi_val = QSpinBox(); self.dpi_val.setRange(120, 640); self.dpi_val.setSingleStep(10)
        cur_dpi = int(cfg.get('hw.lcd.density', 240))
        self.dpi_val.setValue(cur_dpi)
        i = self.dpi_sel.findData(cur_dpi)
        self.dpi_sel.setCurrentIndex(i if i >= 0 else 3)
        self.dpi_val.setEnabled(self.dpi_sel.currentData() == 0)
        self.dpi_sel.currentIndexChanged.connect(lambda _: self.dpi_val.setEnabled(self.dpi_sel.currentData() == 0))
        dpi_row = QHBoxLayout(); dpi_row.addWidget(self.dpi_sel, 1); dpi_row.addWidget(self.dpi_val)
        self.embed = QCheckBox('Tela do Android dentro da janela do MH Play'); self.embed.setChecked(settings.get('embed', True))
        f.addRow('Resolução', self.res)
        f.addRow('Densidade de pixels', dpi_row)
        f.addRow(self.embed)

        sec('Armazenamento')
        self.data_dir = QLabel(settings.get('avd_move_to') or str(emu.AVD_HOME))
        self.data_dir.setStyleSheet('color:#8A8C99;')
        self.data_dir.setWordWrap(True)
        b_dir = QPushButton('Mudar local…')
        b_dir.clicked.connect(self._pick_dir)
        row = QHBoxLayout(); row.addWidget(self.data_dir, 1); row.addWidget(b_dir)
        f.addRow('Dados do Android', row)
        self._new_dir = ''

        sec('Inicialização')
        self.cold = QCheckBox('Ligar do zero sempre (mais lento, só pra resolver problema)'); self.cold.setChecked(settings.get('cold_boot', False))
        f.addRow(self.cold)
        nota = QLabel('FPS máximo = taxa da tela do Android. No Free Fire, ative também "FPS alto" em Gráficos.\n'
                      'Mudanças de CPU, memória, gráficos e tela valem no próximo início.')
        nota.setStyleSheet('color:#8A8C99;font-size:11px;')
        f.addRow(nota)
        bb = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        f.addRow(bb)

    def _pick_dir(self):
        d = QFileDialog.getExistingDirectory(self, 'Onde guardar os dados do Android (apps, conta, Free Fire)?', 'D:\\')
        if not d:
            return
        d = str(Path(d) / 'MHPlay') if Path(d).name.lower() != 'mhplay' else d
        if Path(d).resolve() == emu.AVD_HOME.resolve():
            return
        free = shutil.disk_usage(Path(d).anchor).free / 1024 ** 3
        if free < 20:
            QMessageBox.warning(self, 'MH Play', f'Esse disco tem só {free:.0f} GB livres. Escolha um com pelo menos 20 GB.')
            return
        self._new_dir = d
        self.data_dir.setText(f'{d}   (vai mudar na próxima vez que abrir)')

    def apply(self):
        w, h = (int(v) for v in self.res.currentData().split('x'))
        if self._new_dir:
            self.settings['avd_move_to'] = self._new_dir
        dpi = self.dpi_sel.currentData() or self.dpi_val.value()
        ram = self.ram.currentData() or self.ram_val.value()
        emu.write_avd_config({'hw.cpu.ncore': self.cores.value(), 'hw.ramSize': ram,
                              'hw.lcd.width': w, 'hw.lcd.height': h, 'hw.lcd.density': dpi,
                              'hw.lcd.vsync': self.fpsmax.currentData(),
                              'skin.name': f'{w}x{h}'})
        self.settings.update(gpu=self.gpu.currentData(), gpu_pref=self.gpu_pref.isChecked(),
                             show_fps=self.fps.isChecked(), embed=self.embed.isChecked(),
                             cold_boot=self.cold.isChecked())
        emu.save_settings(self.settings)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = emu.load_settings()
        emu.apply_data_dir(self.settings)
        self.emu = emu.Emulator()
        cfg = emu.read_avd_config()
        self.dev_w = int(cfg.get('hw.lcd.width', 1600))
        self.dev_h = int(cfg.get('hw.lcd.height', 900))
        self.engine = Engine(self.dev_w, self.dev_h)
        self.engine.sens_mult = float(self.settings.get('sens_mult', 0.5))
        self.engine.sens_x = self.settings.get('sens_x')
        self.engine.sens_y = self.settings.get('sens_y')
        self.bridge = Bridge()
        self.embedded = False

        self.setWindowTitle('MH Play')
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window)
        self.resize(1490, 860)
        self._build()

        b = self.bridge
        b.status.connect(self.status.setText)
        b.window_found.connect(self._on_window)
        b.booted.connect(self._on_booted)
        b.toast.connect(lambda m: self.status.setText(m))
        b.fullscreen.connect(self.toggle_fullscreen)
        b.update_found.connect(self._on_update)
        self.engine.on_status = b.status.emit
        self.engine.clip_rect_fn = self._screen_rect
        self.engine.hotkeys[VK_F11] = b.fullscreen.emit

        self.overlay = Overlay()
        self.overlay.show_keys = self.settings.get('show_keys', True)
        b.fps.connect(self._on_fps)
        self.in_game = False
        b.game.connect(self._on_game)
        self._load_keymap(self.settings.get('keymap') or str(DEFAULT_KEYMAP), quiet=True)

        from .input_win import InputHub
        self.hub = InputHub(self.engine)
        self.hub.start()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(400)
        QTimer.singleShot(200, self._boot)

    # ---------- UI ----------
    def _build(self):
        root = QWidget(); root.setObjectName('root')
        v = QVBoxLayout(root); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)

        self.topbar = QWidget(); self.topbar.setObjectName('topbar'); self.topbar.setFixedHeight(40)
        t = QHBoxLayout(self.topbar); t.setContentsMargins(10, 0, 4, 0); t.setSpacing(2)
        logo = QLabel(); logo.setObjectName('logo')
        logo.setPixmap(QPixmap(str(ASSETS / 'logo.png')).scaled(36, 36, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        titles = QVBoxLayout(); titles.setSpacing(0)
        a = QLabel('MH Play'); a.setObjectName('title')
        s = QLabel(f'v{updater.VERSION}  •  Android 11'); s.setObjectName('sub')
        titles.addWidget(a); titles.addWidget(s)
        t.addWidget(logo); t.addSpacing(6); t.addLayout(titles); t.addSpacing(16)
        t.addWidget(tb('', 'Voltar', lambda: self._adb_key(4), ic='back'))
        t.addWidget(tb('', 'Início', lambda: self._adb_key(3), ic='home'))
        t.addWidget(tb('', 'Apps recentes', lambda: self._adb_key(187), ic='recents'))
        t.addStretch(1)
        self.btn_update = tb(' Atualizar', 'Procurar atualização do MH Play', lambda: self._check_update(False), ic='refresh')
        self.btn_update.setStyleSheet('QToolButton{font-size:12px;padding:4px 10px;border:1px solid #3A3C48;border-radius:6px;}'
                                      'QToolButton:hover{border-color:#7C3AED;}')
        t.addWidget(self.btn_update); t.addSpacing(6)
        t.addWidget(tb('', 'Ajuda', self._help, ic='help'))
        t.addWidget(tb('', 'Configurações', self._settings, ic='menu'))
        t.addWidget(tb('', 'Minimizar', self.showMinimized, ic='minimize'))
        t.addWidget(tb('', 'Maximizar', self._toggle_max, ic='maximize'))
        t.addWidget(tb('', 'Fechar', self.close, name='close', ic='close'))
        self.topbar.mousePressEvent = self._drag
        self.topbar.mouseDoubleClickEvent = lambda e: self._toggle_max()
        v.addWidget(self.topbar)

        body = QHBoxLayout(); body.setContentsMargins(0, 0, 0, 0); body.setSpacing(0)
        self.screen = QWidget(); self.screen.setObjectName('screen')
        self.screen.setAttribute(Qt.WA_NativeWindow)
        self.screen.setAttribute(Qt.WA_StyledBackground)
        sl = QVBoxLayout(self.screen)
        self.placeholder = QLabel('Iniciando Android…'); self.placeholder.setObjectName('placeholder')
        self.placeholder.setAlignment(Qt.AlignCenter)
        sl.addWidget(self.placeholder)
        self.screen.resizeEvent = self._screen_resized
        body.addWidget(self.screen, 1)

        self.sidebar = QWidget(); self.sidebar.setObjectName('sidebar'); self.sidebar.setFixedWidth(52)
        sb = QVBoxLayout(self.sidebar); sb.setContentsMargins(4, 8, 4, 8); sb.setSpacing(4)
        apk = tb('APK', 'Instalar APK (enviar arquivo .apk)', self._install_apk, ic='upload', under=True)
        apk.setStyleSheet('QToolButton{font-size:10px;font-weight:600;padding:4px 2px;}')
        for w in (tb('', 'Tela cheia (F11)', self.toggle_fullscreen, ic='fullscreen'),
                  tb('', 'Volume +', lambda: self._adb_key(24), ic='vol_up'),
                  tb('', 'Volume -', lambda: self._adb_key(25), ic='vol_down'),
                  tb('', 'Mapeamento de teclas', self._open_keymap, ic='keyboard'),
                  tb('', 'Modo mira liga/desliga', lambda: self.engine.q.put(('aim', not self.engine.aim)), ic='crosshair'),
                  tb('', 'Abrir Free Fire', self._open_ff, ic='gamepad'),
                  apk,
                  tb('', 'Captura de tela', self._screenshot, ic='camera')):
            w.setFixedWidth(44)
            sb.addWidget(w, 0, Qt.AlignHCenter)
        sb.addStretch(1)
        for w in (tb('', 'Configurações', self._settings, ic='settings'),
                  tb('', 'Voltar', lambda: self._adb_key(4), ic='back'),
                  tb('', 'Início', lambda: self._adb_key(3), ic='home'),
                  tb('', 'Recentes', lambda: self._adb_key(187), ic='recents')):
            w.setFixedWidth(44)
            sb.addWidget(w, 0, Qt.AlignHCenter)
        body.addWidget(self.sidebar)
        v.addLayout(body, 1)

        self.status = QLabel('Preparando…'); self.status.setObjectName('status')
        v.addWidget(self.status)
        self.setCentralWidget(root)

    def _drag(self, e):
        if e.button() == Qt.LeftButton and self.windowHandle():
            self.windowHandle().startSystemMove()

    def _toggle_max(self):
        self.showNormal() if self.isMaximized() else self.showMaximized()

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal(); self.topbar.show(); self.sidebar.show(); self.status.show()
        else:
            self.topbar.hide(); self.sidebar.hide(); self.status.hide(); self.showFullScreen()

    # ---------- emulador ----------
    def _boot(self):
        if not self.emu.installed():
            QMessageBox.critical(self, 'MH Play', 'Base Android não encontrada.\nRode o INSTALAR.bat primeiro.')
            return
        threading.Thread(target=self._boot_thread, daemon=True).start()

    def _boot_thread(self):
        b = self.bridge
        try:
            dest = self.settings.get('avd_move_to')
            if dest:
                emu.kill_leftovers()
                try:
                    newp = emu.move_data_dir(dest, b.status.emit)
                    self.settings['avd_home'] = str(newp)
                except Exception as e:
                    log.exception('mover dados')
                    b.toast.emit(f'Não consegui mover os dados: {e}')
                self.settings['avd_move_to'] = ''
                emu.save_settings(self.settings)
            ok, msg = self.emu.ensure_disk()
            if not ok:
                b.booted.emit(False, msg)
                return
            warn = self.emu.tune_for_speed(self.settings)
            if self.settings.get('gpu_pref', True):
                self.emu.set_gpu_preference()
            b.status.emit(warn or msg or 'Ligando o Android…')
            self.t_boot = time.time()
            locale = None if self.settings.get('locale_set') else 'pt-BR'
            self.emu.start(cold=self.settings.get('cold_boot', False) or bool(locale),
                           gpu=self.settings.get('gpu', 'host'), locale=locale)
            if locale:
                self.settings['locale_set'] = True
                emu.save_settings(self.settings)
            if self.emu.find_window():
                b.window_found.emit()
            else:
                err = self.emu.last_error()
                b.booted.emit(False, 'O Android não abriu.' + (f'\n\nMotivo: {err}' if err else '')
                              + f'\n\nLog: {emu.LOG_DIR}\\emulator.log')
                return
            if not warn:
                b.status.emit('Carregando Android… (a primeira vez leva 1-2 min; depois, segundos)')
            if not self.emu.wait_boot():
                b.booted.emit(False, 'O Android não terminou de iniciar. Veja logs\\emulator.log')
                return
            from .touch import TouchClient
            tc = TouchClient(emu.GRPC_PORT)
            if not tc.wait_ready():
                b.booted.emit(False, 'Android ligou, mas o controle de toque (gRPC) não conectou.')
                return
            self.engine.touch = tc
            log.info('Android pronto em %.1f s', time.time() - self.t_boot)
            b.booted.emit(True, '')
            threading.Thread(target=self._fps_thread, daemon=True).start()
            self._tune_android()
        except Exception as e:
            log.exception('boot')
            b.booted.emit(False, f'Erro ao iniciar: {e}')

    def _on_window(self):
        self.engine.allowed_pids.add(self.emu.pid)
        self.engine.emu_pid = self.emu.pid
        if self.settings.get('embed', True):
            try:
                self.emu.embed(int(self.screen.winId()))
                self.embedded = True
                self.placeholder.hide()
                for ms in (300, 1500, 5000):
                    QTimer.singleShot(ms, self._refit)
            except Exception:
                log.exception('embed')
        self.emu.hide_extra_windows()

    def _on_booted(self, ok, msg):
        if ok:
            self.engine._status()
            self.status.setText(self.status.text() + f'   |   Android pronto em {time.time() - self.t_boot:.0f}s')
            if not self.settings.get('dica_vista'):
                self.settings['dica_vista'] = True
                emu.save_settings(self.settings)
                QMessageBox.information(self, 'MH Play pronto!', (
                    'Android ligado!\n\nPra instalar o Free Fire:\n'
                    '• Arraste a tela de baixo pra cima → abra a Play Store → entre com sua conta Google → instale o Free Fire.\n'
                    '• Ou clique no botão APK na barra da direita.\n\n'
                    'O que você instalar fica salvo pra sempre, mesmo atualizando o MH Play.\n'
                    'Depois é só clicar no botão do controle (Abrir Free Fire) na barra da direita.'))
            QTimer.singleShot(3000, lambda: self._check_update(silent=True))
        else:
            self.status.setText(msg)
            QMessageBox.warning(self, 'MH Play', msg)

    def _tick(self):
        if self.emu.hwnd:
            self.emu.hide_extra_windows()
        self._place_overlay()
        if self.emu.proc and not self.emu.running():
            self.status.setText('O Android foi encerrado. Feche e abra o MH Play de novo.')
            self.timer.stop()

    def _fit(self):
        """Encaixa a tela do Android mantendo 16:9 (o emulador nao aceita outro formato), centralizada."""
        if not self.embedded:
            return
        r = self.screen.devicePixelRatioF()
        W, H = int(self.screen.width() * r), int(self.screen.height() * r)
        ar = self.dev_w / self.dev_h
        if W / max(H, 1) > ar:
            h, w = H, int(round(H * ar))
        else:
            w, h = W, int(round(W / ar))
        x, y = (W - w) // 2, (H - h) // 2
        self.emu.resize(x, y, w, h)
        g = self.screen.mapToGlobal(QPoint(0, 0))
        self.android_rect = QRect(g.x() + int(x / r), g.y() + int(y / r), int(w / r), int(h / r))
        self._place_overlay()

    def _refit(self):
        self.emu._last_rect = None
        self._fit()

    def _screen_resized(self, e):
        self._fit()

    def _screen_rect(self):
        if self.embedded:
            g = self.screen.mapToGlobal(self.screen.rect().topLeft())
            r = self.screen.devicePixelRatioF()
            return (int(g.x() * r), int(g.y() * r),
                    int((g.x() + self.screen.width()) * r), int((g.y() + self.screen.height()) * r))
        return None

    # ---------- ações ----------
    def _bg(self, fn, done=None):
        def run():
            try:
                res = fn()
                if done:
                    self.bridge.toast.emit(done if isinstance(done, str) else done(res))
            except Exception as e:
                self.bridge.toast.emit(f'Erro: {e}')
        threading.Thread(target=run, daemon=True).start()

    def _adb_key(self, code):
        self._bg(lambda: self.emu.key(code))

    def _open_ff(self):
        self._bg(self.emu.open_freefire, 'Abrindo Free Fire… (se não abrir, instale pela Play Store)')

    def _install_apk(self):
        p, _ = QFileDialog.getOpenFileName(self, 'Instalar APK', '', 'APK (*.apk)')
        if p:
            self.status.setText('Instalando APK…')
            self._bg(lambda: self.emu.install_apk(p), lambda r: f'APK: {r.splitlines()[-1] if r else "ok"}')

    def _screenshot(self):
        d = Path.home() / 'Pictures' / 'MH Play'
        d.mkdir(parents=True, exist_ok=True)
        f = d / time.strftime('mh_%Y%m%d_%H%M%S.png')
        self._bg(lambda: self.emu.screenshot(f), f'Captura salva em {f}')

    def _open_keymap(self):
        dlg = KeymapDialog(self, self.engine, self.settings, str(DEFAULT_KEYMAP))
        if dlg.exec():
            r = dlg.result_values()
            if r['layout'] is not None:
                self.engine.set_layout(r['layout'])
                self.overlay.layout_obj = r['layout']
                self.settings['keymap'] = r['layout'].path
            self.engine.q.put(('enable', r['enabled']))
            self.engine.sens_x, self.engine.sens_y = r['sens_x'], r['sens_y']
            self.settings.update(show_keys=r['show_keys'], sens_x=r['sens_x'], sens_y=r['sens_y'])
            emu.save_settings(self.settings)
            self.overlay.show_keys = r['show_keys']
            self.overlay.update()

    def _tune_android(self):
        """Primeira vez: deixa o Android leve pra jogo e coloca o fundo MH Play."""
        from . import android_tune
        if self.settings.get('android_tuned', 0) < android_tune.TUNE_VERSION:
            self.bridge.status.emit('Otimizando o Android pra jogo (só desta vez)…')
            n = android_tune.apply(self.emu)
            self.settings['android_tuned'] = android_tune.TUNE_VERSION
            emu.save_settings(self.settings)
            self.bridge.toast.emit(f'Android otimizado: animações, Bluetooth, rotação e localização desligados; '
                                   f'{n} apps de fábrica desativados.')
        if not self.settings.get('wallpaper_set'):
            try:
                if android_tune.push_wallpaper(self.emu, ASSETS / 'wallpaper.png'):
                    self.settings['wallpaper_set'] = True
                    emu.save_settings(self.settings)
                    self.bridge.toast.emit('Plano de fundo MH Play: toque em "Definir plano de fundo" na tela do Android.')
            except Exception:
                log.exception('wallpaper')

    def _fps_thread(self):
        last = None
        tick = 0
        while self.emu.running():
            t0 = time.time()
            if tick % 2 == 0:  # a cada 2 s: o Free Fire esta aberto?
                try:
                    in_game = self.emu.foreground_package() == emu.FF_PACKAGE
                    if in_game != self.in_game:
                        self.in_game = in_game
                        self.bridge.game.emit(in_game)
                except Exception:
                    pass
            tick += 1
            if self.settings.get('show_fps', True) and self.in_game:
                try:
                    v = self.emu.game_fps()
                    self.bridge.fps.emit(v)
                except Exception:
                    log.exception('fps')
            elif last is not None:
                self.bridge.fps.emit(None)
            last = None if not self.in_game else True
            time.sleep(max(0.0, 1.0 - (time.time() - t0)))

    def _on_game(self, on):
        """Teclas na tela so aparecem com o Free Fire aberto."""
        self.overlay.in_game = on
        self.overlay.update()
        self.engine.in_game = on
        self.status.setText('Free Fire aberto: mapeamento de teclas ativo' if on
                            else 'Fora do jogo: teclado digitando normal')
        if not on and self.engine.aim:
            self.engine.q.put(('aim', False))

    def _on_fps(self, v):
        self.overlay.fps = v
        self.overlay.update()

    def _place_overlay(self):
        ov = getattr(self, 'overlay', None)
        if ov is None:
            return
        want = (self.embedded and getattr(self, 'android_rect', None) is not None and not self.isMinimized()
                and (ov.show_keys or self.settings.get('show_fps', True)) and self.engine._active())
        ov.show_fps = self.settings.get('show_fps', True)
        if ov.aim != self.engine.aim:
            ov.aim = self.engine.aim
            ov.update()
        if want:
            if ov.geometry() != self.android_rect:
                ov.setGeometry(self.android_rect)
            if not ov.isVisible():
                ov.show()
        elif ov.isVisible():
            ov.hide()

    def _load_keymap(self, path, quiet=False):
        try:
            lay = load_cfg(path)
            self.engine.set_layout(lay)
            self.overlay.layout_obj = lay
            self.settings['keymap'] = str(path)
            emu.save_settings(self.settings)
            if not quiet:
                self.status.setText(f'Layout "{lay.name}" carregado')
        except Exception as e:
            if not quiet:
                QMessageBox.warning(self, 'MH Play', f'Não consegui ler o layout:\n{e}')

    def _import_keymap(self):
        p, _ = QFileDialog.getOpenFileName(self, 'Importar layout', str(APP_DIR / 'keymaps'), 'Layout (*.cfg *.json)')
        if p:
            self._load_keymap(p)

    def _settings(self):
        dlg = SettingsDialog(self, self.settings)
        if dlg.exec():
            dlg.apply()
            if self.settings.get('avd_move_to'):
                QMessageBox.information(self, 'MH Play', 'Feche e abra o MH Play: antes de ligar o Android, os dados vão ser '
                                        'movidos para o novo local. Seu login e o Free Fire continuam.')
            self.status.setText('Configurações salvas.')

    def _check_update(self, silent=False):
        if not silent and getattr(self, '_pending_update', None):
            info, self._pending_update = self._pending_update, None
            self._on_update(info, False)
            return
        url = self.settings.get('update_url') or UPDATE_URL
        if not url:
            if not silent:
                QMessageBox.information(self, 'MH Play', 'Atualização automática ainda não configurada.')
            return

        def run():
            try:
                info = updater.check(url)
                self.bridge.update_found.emit(info or {}, silent)
            except Exception as e:
                if not silent:
                    self.bridge.toast.emit(f'Não consegui verificar atualização: {e}')
        threading.Thread(target=run, daemon=True).start()

    def _on_update(self, info, silent):
        if not info:
            if not silent:
                QMessageBox.information(self, 'MH Play', f'Você já está na versão mais nova ({updater.VERSION}).')
            return
        self.btn_update.setText(f" Atualizar para {info['version']}")
        self.btn_update.setStyleSheet('QToolButton{font-size:12px;padding:4px 10px;background:#7C3AED;border-radius:6px;}')
        if silent:
            self.status.setText(f"Nova versão {info['version']} disponível: clique em Atualizar lá em cima.")
            self._pending_update = info
            return
        notas = info.get('notas', '')
        r = QMessageBox.question(self, 'Atualização disponível',
                                 f"Nova versão {info['version']} disponível.\n\n{notas}\n\nAtualizar agora? "
                                 'O MH Play vai fechar e abrir de novo. Seus apps e o Free Fire continuam instalados.')
        if r != QMessageBox.Yes:
            return
        self.status.setText('Baixando atualização…')
        QApplication.processEvents()
        try:
            updater.apply(info, APP_DIR)
        except Exception as e:
            QMessageBox.warning(self, 'MH Play', f'A atualização falhou: {e}')
            return
        self._restart_after = True
        self.close()

    def _help(self):
        QMessageBox.information(self, 'Atalhos', (
            "'  (tecla ao lado do 1)  liga/desliga a mira\n"
            'Esc  sai da mira\nF9  liga/desliga o mapeamento\nF11  tela cheia\n\n'
            'Clique esquerdo atira quando a mira está ligada.\n'
            'Perfis .cfg do App Player: botão Mapeamento de teclas > Importar perfil.'))

    def closeEvent(self, e):
        self.engine.q.put(('enable', False))
        self.hub.stop()
        self.overlay.hide()
        self.hide()  # some na hora; o Android termina de salvar o estado em segundo plano
        QApplication.processEvents()
        self.emu.stop()
        if getattr(self, '_restart_after', False):
            updater.restart(APP_DIR)
        e.accept()


def make_icon():
    if (ASSETS / 'logo.ico').exists():
        return QIcon(str(ASSETS / 'logo.ico'))
    return _fallback_icon()


def _fallback_icon():
    pm = QPixmap(256, 256)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setBrush(QColor('#7C3AED')); p.setPen(Qt.NoPen)
    p.drawRoundedRect(8, 8, 240, 240, 48, 48)
    p.setPen(QColor('white')); p.setFont(QFont('Segoe UI', 96, QFont.Black))
    p.drawText(pm.rect(), Qt.AlignCenter, 'MH')
    p.end()
    return QIcon(pm)


def create_shortcut():
    """Cria/atualiza o atalho 'MH Play' na area de trabalho com a logo."""
    try:
        import subprocess
        target = APP_DIR / 'INICIAR.bat'
        icon = ASSETS / 'logo.ico'
        ps = (
            "$d=[Environment]::GetFolderPath('Desktop');"
            "$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'MH Play.lnk'));"
            f"$s.TargetPath='{target}';$s.WorkingDirectory='{APP_DIR}';"
            f"$s.IconLocation='{icon},0';$s.WindowStyle=7;$s.Description='MH Play';$s.Save()"
        )
        subprocess.Popen(['powershell', '-NoProfile', '-Command', ps], creationflags=0x08000000)
    except Exception:
        log.exception('atalho')


def _excepthook(t, v, tb_):
    import traceback
    msg = ''.join(traceback.format_exception(t, v, tb_))
    log.error('Erro nao tratado:\n%s', msg)
    try:
        QMessageBox.warning(None, 'MH Play', f'Ocorreu um erro:\n\n{v}\n\nDetalhes em {emu.LOG_DIR}\\mh.log')
    except Exception:
        pass


def main():
    sys.excepthook = _excepthook
    if os.name != 'nt':
        print('O MH Play roda no Windows.')
        return
    import ctypes
    # so uma janela do MH Play por vez: se ja estiver aberto, traz pra frente e sai
    k32, u32 = ctypes.windll.kernel32, ctypes.windll.user32
    k32.CreateMutexW.restype = ctypes.c_void_p
    _mutex = k32.CreateMutexW(None, False, 'Local\\MHPlay.SingleInstance')  # noqa: F841 (fica vivo ate sair)
    if k32.GetLastError() == 183:  # ERROR_ALREADY_EXISTS
        h = u32.FindWindowW(None, 'MH Play')
        if h:
            u32.ShowWindow(h, 9)  # SW_RESTORE
            u32.SetForegroundWindow(h)
        return
    # identidade propria na barra de tarefas (nao agrupa com outros apps Python, como o MH Creator Pro)
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('MHPlay.App')
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(sys.argv)
    app.setFont(QFont('Segoe UI', 9))
    app.setStyleSheet(STYLE)
    app.setWindowIcon(make_icon())
    create_shortcut()
    w = MainWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
