"""Captura de teclado/mouse no Windows.

- Hooks de baixo nivel (WH_KEYBOARD_LL / WH_MOUSE_LL) para ler e "engolir" teclas e cliques mapeados.
- Raw Input para o movimento do mouse: deltas crus do sensor, sem aceleracao do Windows.
  E isso que evita a mira "puxando".
"""
import ctypes
import ctypes.wintypes as wt
import logging
import threading

log = logging.getLogger('mh.input')

user32 = ctypes.WinDLL('user32', use_last_error=True)
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)

LRESULT = ctypes.c_ssize_t
HOOKPROC = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wt.WPARAM, wt.LPARAM)
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)

WH_KEYBOARD_LL, WH_MOUSE_LL = 13, 14
WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP = 0x100, 0x101, 0x104, 0x105
WM_INPUT = 0x00FF
WM_QUIT = 0x0012
RID_INPUT = 0x10000003
RIDEV_INPUTSINK = 0x00000100
RIM_TYPEMOUSE = 0
MOUSE_BUTTONS = {
    0x201: ('MouseLButton', True), 0x202: ('MouseLButton', False),
    0x204: ('MouseRButton', True), 0x205: ('MouseRButton', False),
    0x207: ('MouseMButton', True), 0x208: ('MouseMButton', False),
}
WM_XBUTTONDOWN, WM_XBUTTONUP = 0x20B, 0x20C


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [('vkCode', wt.DWORD), ('scanCode', wt.DWORD), ('flags', wt.DWORD),
                ('time', wt.DWORD), ('dwExtraInfo', ctypes.c_size_t)]


class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [('pt', wt.POINT), ('mouseData', wt.DWORD), ('flags', wt.DWORD),
                ('time', wt.DWORD), ('dwExtraInfo', ctypes.c_size_t)]


class RAWINPUTDEVICE(ctypes.Structure):
    _fields_ = [('usUsagePage', wt.USHORT), ('usUsage', wt.USHORT), ('dwFlags', wt.DWORD), ('hwndTarget', wt.HWND)]


class RAWINPUTHEADER(ctypes.Structure):
    _fields_ = [('dwType', wt.DWORD), ('dwSize', wt.DWORD), ('hDevice', wt.HANDLE), ('wParam', wt.WPARAM)]


class _BTN(ctypes.Structure):
    _fields_ = [('usButtonFlags', wt.USHORT), ('usButtonData', wt.USHORT)]


class _BU(ctypes.Union):
    _fields_ = [('ulButtons', wt.ULONG), ('s', _BTN)]


class RAWMOUSE(ctypes.Structure):
    _fields_ = [('usFlags', wt.USHORT), ('u', _BU), ('ulRawButtons', wt.ULONG),
                ('lLastX', wt.LONG), ('lLastY', wt.LONG), ('ulExtraInformation', wt.ULONG)]


class RAWINPUT(ctypes.Structure):
    _fields_ = [('header', RAWINPUTHEADER), ('mouse', RAWMOUSE)]


class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [('cbSize', wt.UINT), ('style', wt.UINT), ('lpfnWndProc', WNDPROC),
                ('cbClsExtra', ctypes.c_int), ('cbWndExtra', ctypes.c_int), ('hInstance', wt.HINSTANCE),
                ('hIcon', wt.HICON), ('hCursor', wt.HANDLE), ('hbrBackground', wt.HBRUSH),
                ('lpszMenuName', wt.LPCWSTR), ('lpszClassName', wt.LPCWSTR), ('hIconSm', wt.HICON)]


user32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wt.HINSTANCE, wt.DWORD]
user32.SetWindowsHookExW.restype = wt.HHOOK
user32.CallNextHookEx.argtypes = [wt.HHOOK, ctypes.c_int, wt.WPARAM, wt.LPARAM]
user32.CallNextHookEx.restype = LRESULT
user32.UnhookWindowsHookEx.argtypes = [wt.HHOOK]
user32.DefWindowProcW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
user32.DefWindowProcW.restype = LRESULT
user32.GetRawInputData.argtypes = [wt.HANDLE, wt.UINT, ctypes.c_void_p, ctypes.POINTER(wt.UINT), wt.UINT]
user32.GetRawInputData.restype = wt.UINT
user32.RegisterRawInputDevices.argtypes = [ctypes.POINTER(RAWINPUTDEVICE), wt.UINT, wt.UINT]
user32.RegisterClassExW.argtypes = [ctypes.POINTER(WNDCLASSEXW)]
user32.RegisterClassExW.restype = wt.ATOM
user32.CreateWindowExW.argtypes = [wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD, ctypes.c_int, ctypes.c_int,
                                   ctypes.c_int, ctypes.c_int, wt.HWND, wt.HMENU, wt.HINSTANCE, wt.LPVOID]
user32.CreateWindowExW.restype = wt.HWND
user32.GetMessageW.argtypes = [ctypes.POINTER(wt.MSG), wt.HWND, wt.UINT, wt.UINT]
user32.TranslateMessage.argtypes = [ctypes.POINTER(wt.MSG)]
user32.DispatchMessageW.argtypes = [ctypes.POINTER(wt.MSG)]
user32.DispatchMessageW.restype = LRESULT
user32.PostThreadMessageW.argtypes = [wt.DWORD, wt.UINT, wt.WPARAM, wt.LPARAM]
kernel32.GetModuleHandleW.argtypes = [wt.LPCWSTR]
kernel32.GetModuleHandleW.restype = wt.HMODULE


class InputHub(threading.Thread):
    """Thread com loop de mensagens: hooks + raw input. Encaminha tudo para o Engine."""

    def __init__(self, engine):
        super().__init__(daemon=True, name='mh-input')
        self.engine = engine
        self.tid = None
        self._refs = []

    def stop(self):
        if self.tid:
            user32.PostThreadMessageW(self.tid, WM_QUIT, 0, 0)

    def _kb(self, n, wparam, lparam):
        if n == 0:
            k = ctypes.cast(lparam, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
            if not (k.flags & 0x10):  # ignora eventos injetados
                down = wparam in (WM_KEYDOWN, WM_SYSKEYDOWN)
                try:
                    if self.engine.on_key(k.vkCode, down):
                        return 1
                except Exception:
                    log.exception('on_key')
        return user32.CallNextHookEx(None, n, wparam, lparam)

    def _ms(self, n, wparam, lparam):
        if n == 0:
            m = ctypes.cast(lparam, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
            if not (m.flags & 0x01):
                ev = MOUSE_BUTTONS.get(wparam)
                if ev is None and wparam in (WM_XBUTTONDOWN, WM_XBUTTONUP):
                    xb = (m.mouseData >> 16) & 0xFFFF
                    ev = (f'MouseXButton{xb}', wparam == WM_XBUTTONDOWN)
                if ev:
                    try:
                        if self.engine.on_mouse_button(ev[0], ev[1]):
                            return 1
                    except Exception:
                        log.exception('on_mouse_button')
        return user32.CallNextHookEx(None, n, wparam, lparam)

    def _wnd(self, hwnd, msg, wparam, lparam):
        if msg == WM_INPUT:
            size = wt.UINT(0)
            hdr = ctypes.sizeof(RAWINPUTHEADER)
            user32.GetRawInputData(lparam, RID_INPUT, None, ctypes.byref(size), hdr)
            if size.value:
                buf = ctypes.create_string_buffer(size.value)
                if user32.GetRawInputData(lparam, RID_INPUT, buf, ctypes.byref(size), hdr) == size.value:
                    ri = ctypes.cast(buf, ctypes.POINTER(RAWINPUT)).contents
                    if ri.header.dwType == RIM_TYPEMOUSE and not (ri.mouse.usFlags & 0x01):
                        if ri.mouse.lLastX or ri.mouse.lLastY:
                            self.engine.on_mouse_move(ri.mouse.lLastX, ri.mouse.lLastY)
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    def run(self):
        self.tid = kernel32.GetCurrentThreadId()
        hinst = kernel32.GetModuleHandleW(None)
        wndproc = WNDPROC(self._wnd)
        kb = HOOKPROC(self._kb)
        ms = HOOKPROC(self._ms)
        self._refs = [wndproc, kb, ms]

        wc = WNDCLASSEXW()
        wc.cbSize = ctypes.sizeof(WNDCLASSEXW)
        wc.lpfnWndProc = wndproc
        wc.hInstance = hinst
        wc.lpszClassName = 'MHEmulatorRawInput'
        user32.RegisterClassExW(ctypes.byref(wc))
        hwnd = user32.CreateWindowExW(0, wc.lpszClassName, 'mh-raw', 0, 0, 0, 0, 0, None, None, hinst, None)

        rid = RAWINPUTDEVICE(0x01, 0x02, RIDEV_INPUTSINK, hwnd)
        if not user32.RegisterRawInputDevices(ctypes.byref(rid), 1, ctypes.sizeof(RAWINPUTDEVICE)):
            log.error('RegisterRawInputDevices falhou: %s', ctypes.get_last_error())

        hk = user32.SetWindowsHookExW(WH_KEYBOARD_LL, kb, hinst, 0)
        hm = user32.SetWindowsHookExW(WH_MOUSE_LL, ms, hinst, 0)
        if not hk or not hm:
            log.error('SetWindowsHookEx falhou: %s', ctypes.get_last_error())
        log.info('Input pronto (hooks + raw input)')

        msg = wt.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        user32.UnhookWindowsHookEx(hk)
        user32.UnhookWindowsHookEx(hm)
