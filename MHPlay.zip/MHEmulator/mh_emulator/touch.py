"""Envio de multitoque para o emulador via gRPC (EmulatorController.sendTouch)."""
import logging
import sys
from pathlib import Path

import grpc

sys.path.insert(0, str(Path(__file__).parent / 'proto'))
import emulator_controller_pb2 as pb  # noqa: E402  (gerado pelo setup.ps1)
import emulator_controller_pb2_grpc as pbg  # noqa: E402

log = logging.getLogger('mh.touch')

try:
    NEVER_EXPIRE = pb.Touch.NEVER_EXPIRE
except AttributeError:
    NEVER_EXPIRE = None


class TouchClient:
    def __init__(self, port):
        self.channel = grpc.insecure_channel(f'localhost:{port}')
        self.stub = pbg.EmulatorControllerStub(self.channel)
        self.ok = False
        self.errors = 0

    def wait_ready(self, timeout=30):
        try:
            grpc.channel_ready_future(self.channel).result(timeout=timeout)
            self.ok = True
        except Exception as e:
            log.error('gRPC indisponivel: %s', e)
            self.ok = False
        return self.ok

    def send(self, tid, x, y, down):
        t = pb.Touch(x=int(x), y=int(y), identifier=int(tid), pressure=1 if down else 0)
        if down and NEVER_EXPIRE is not None:
            t.expiration = NEVER_EXPIRE
        try:
            self.stub.sendTouch(pb.TouchEvent(touches=[t]), timeout=0.5)
        except Exception as e:
            self.errors += 1
            if self.errors < 20:
                log.warning('sendTouch falhou: %s', e)

    def key(self, vk, down):
        """Tecla do Windows -> codigo Linux (evdev), que e o que o Android entende."""
        code = VK_TO_EVDEV.get(int(vk))
        if code is None:
            return
        try:
            ev = pb.KeyboardEvent(keyCode=code)
            ev.codeType = getattr(pb.KeyboardEvent, 'Evdev', 1)
            ev.eventType = getattr(pb.KeyboardEvent, 'keydown' if down else 'keyup', 0 if down else 1)
            self.stub.sendKey(ev, timeout=0.5)
        except Exception as e:
            self.errors += 1
            if self.errors < 20:
                log.warning('sendKey falhou: %s', e)


# Virtual-key do Windows -> KEY_* do Linux (linux/input-event-codes.h)
VK_TO_EVDEV = {
    0x08: 14, 0x09: 15, 0x0D: 28, 0x1B: 1, 0x20: 57, 0x14: 58,
    0x10: 42, 0xA0: 42, 0xA1: 54, 0x11: 29, 0xA2: 29, 0xA3: 97, 0x12: 56, 0xA4: 56, 0xA5: 100,
    0x21: 104, 0x22: 109, 0x23: 107, 0x24: 102, 0x25: 105, 0x26: 103, 0x27: 106, 0x28: 108,
    0x2D: 110, 0x2E: 111,
    0xBA: 39, 0xBB: 13, 0xBC: 51, 0xBD: 12, 0xBE: 52, 0xBF: 53, 0xC0: 41,
    0xDB: 26, 0xDC: 43, 0xDD: 27, 0xDE: 40, 0xC1: 89, 0xC2: 121, 0xE2: 86,
    # teclado numerico: sempre numeros (o Num Lock do Android e separado do PC)
    0x60: 11, 0x61: 2, 0x62: 3, 0x63: 4, 0x64: 5, 0x65: 6, 0x66: 7, 0x67: 8, 0x68: 9, 0x69: 10,
    0x6A: 55, 0x6B: 78, 0x6D: 12, 0x6E: 52, 0x6F: 53,
}
for _ch, _code in zip('ABCDEFGHIJKLMNOPQRSTUVWXYZ',
                      (30, 48, 46, 32, 18, 33, 34, 35, 23, 36, 37, 38, 50, 49, 24, 25, 16, 19, 31, 20, 22, 47, 17, 45, 21, 44)):
    VK_TO_EVDEV[ord(_ch)] = _code
for _i, _code in enumerate((11, 2, 3, 4, 5, 6, 7, 8, 9, 10)):
    VK_TO_EVDEV[0x30 + _i] = _code
for _i, _code in enumerate((59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 87, 88)):
    VK_TO_EVDEV[0x70 + _i] = _code
