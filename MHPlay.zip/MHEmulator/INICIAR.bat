@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
    echo.
    echo  A instalacao ainda nao foi concluida.
    echo  Rode o INSTALAR.bat primeiro e espere aparecer "Pronto".
    echo  Se der erro, mande o arquivo:
    echo  %LOCALAPPDATA%\MHEmulator\logs\instalacao.log
    echo.
    pause
    exit /b
)
start "" ".venv\Scripts\pythonw.exe" -m mh_emulator.app
