# MH Play - instalador
# Instala: Windows Hypervisor Platform, Java 17, Python, Android SDK (emulador + Android 11 Play Store x86_64
# com traducao ARM), cria o dispositivo virtual otimizado e prepara o ambiente Python.

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Join-Path $env:LOCALAPPDATA 'MHEmulator'
$sdk  = Join-Path $root 'sdk'
$avdHome = Join-Path $root 'avd'
# se os dados do Android foram movidos pra outro disco (Configuracoes > Dados do Android), usa esse local
try {
    $st = Get-Content (Join-Path $root 'settings.json') -Raw -ErrorAction Stop | ConvertFrom-Json
    if ($st.avd_home -and (Test-Path (Join-Path $st.avd_home 'MH_FF.avd'))) { $avdHome = $st.avd_home }
} catch {}
$avdName = 'MH_FF'
$image = 'system-images;android-30;google_apis_playstore;x86_64'
New-Item -ItemType Directory -Force -Path $root, $sdk, $avdHome, (Join-Path $root 'logs') | Out-Null
Start-Transcript -Path (Join-Path $root 'logs\instalacao.log') -Force | Out-Null

trap {
    Write-Host "`nERRO: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Mande este arquivo pro suporte: $root\logs\instalacao.log" -ForegroundColor Yellow
    Stop-Transcript | Out-Null
    exit 1
}
function Check($what) { if ($LASTEXITCODE -ne 0) { throw "$what falhou (codigo $LASTEXITCODE)" } }
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw 'winget nao encontrado. Instale o "Instalador de Aplicativo" pela Microsoft Store e rode de novo.'
}

function Step($t) { Write-Host "`n==> $t" -ForegroundColor Cyan }
function Refresh-Path {
    $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User')
}

# 1. Hypervisor
Step 'Verificando Windows Hypervisor Platform'
$needReboot = $false
$feat = Get-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform
if ($feat.State -ne 'Enabled') {
    Enable-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform -All -NoRestart | Out-Null
    $needReboot = $true
    Write-Host 'Hypervisor Platform ativado (vai precisar reiniciar o PC no final).' -ForegroundColor Yellow
} else { Write-Host 'OK' }

# 2. Java 17 (o sdkmanager precisa)
Step 'Verificando Java 17'
$jdk = Get-ChildItem 'C:\Program Files\Eclipse Adoptium' -Directory -Filter 'jdk-17*' -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $jdk) {
    winget install -e --id EclipseAdoptium.Temurin.17.JDK --silent --accept-source-agreements --accept-package-agreements
    Refresh-Path
    $jdk = Get-ChildItem 'C:\Program Files\Eclipse Adoptium' -Directory -Filter 'jdk-17*' | Select-Object -First 1
}
$env:JAVA_HOME = $jdk.FullName
$env:Path = "$($jdk.FullName)\bin;$env:Path"
Write-Host "Java: $($jdk.FullName)"

# 3. Python (ignora o atalho falso da Microsoft Store em WindowsApps)
Step 'Verificando Python'
function Find-Python {
    $cands = @()
    $cands += Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe" -ErrorAction SilentlyContinue | Sort-Object FullName -Descending
    $cands += Get-ChildItem 'C:\Program Files\Python3*\python.exe' -ErrorAction SilentlyContinue | Sort-Object FullName -Descending
    foreach ($c in (Get-Command python -All -ErrorAction SilentlyContinue)) { if ($c.Source -notmatch 'WindowsApps') { $cands += Get-Item $c.Source } }
    foreach ($c in $cands) {
        $v = & $c.FullName -c "import sys;print(sys.version_info[0]*100+sys.version_info[1])" 2>$null
        if ($v -and [int]$v -ge 310) { return $c.FullName }
    }
    return $null
}
$pyExe = Find-Python
if (-not $pyExe) {
    winget install -e --id Python.Python.3.12 --scope user --silent --accept-source-agreements --accept-package-agreements
    Refresh-Path
    $pyExe = Find-Python
}
if (-not $pyExe) { throw 'Nao consegui instalar o Python 3.12. Instale manualmente em python.org (marque "Add to PATH") e rode de novo.' }
Write-Host "Python: $pyExe"

# 4. Android command-line tools
Step 'Baixando Android command-line tools'
$sm = Join-Path $sdk 'cmdline-tools\latest\bin\sdkmanager.bat'
if (-not (Test-Path $sm)) {
    $zip = Join-Path $root 'cmdline-tools.zip'
    Invoke-WebRequest 'https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip' -OutFile $zip
    $tmp = Join-Path $root 'cmdtmp'
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Expand-Archive $zip -DestinationPath $tmp
    New-Item -ItemType Directory -Force -Path (Join-Path $sdk 'cmdline-tools') | Out-Null
    Move-Item (Join-Path $tmp 'cmdline-tools') (Join-Path $sdk 'cmdline-tools\latest')
    Remove-Item $tmp, $zip -Recurse -Force
}

# 5. Pacotes do SDK
Step 'Instalando emulador, platform-tools e imagem Android 11 (demora, ~2 GB)'
$env:ANDROID_SDK_ROOT = $sdk
$env:ANDROID_HOME = $sdk
$env:ANDROID_AVD_HOME = $avdHome
(1..40 | ForEach-Object { 'y' }) | & $sm --sdk_root=$sdk --licenses | Out-Null
& $sm --sdk_root=$sdk 'platform-tools' 'emulator' $image
Check 'Download do Android SDK'

# 6. Dispositivo virtual
Step 'Criando dispositivo virtual MH_FF'
$avdm = Join-Path $sdk 'cmdline-tools\latest\bin\avdmanager.bat'
$cfg = Join-Path $avdHome "$avdName.avd\config.ini"
$avdExists = Test-Path $cfg
if ($avdExists) {
    Write-Host 'Dispositivo ja existe: mantendo seus apps, contas e o Free Fire instalados.' -ForegroundColor Green
} else {
    'no' | & $avdm create avd -n $avdName -k $image -d 'pixel_4'
    Check 'Criacao do dispositivo virtual'
}

# 7. Otimizacao (Ryzen 7 5700X + GTX 1650)
Step 'Aplicando configuracao otimizada'
if (-not $avdExists) {
$settings = [ordered]@{
    'hw.cpu.ncore' = '6'; 'hw.ramSize' = '4096'; 'vm.heapSize' = '576'
    'hw.gpu.enabled' = 'yes'; 'hw.gpu.mode' = 'host'
    'hw.lcd.width' = '1600'; 'hw.lcd.height' = '900'; 'hw.lcd.density' = '240'
    'hw.initialOrientation' = 'landscape'; 'hw.keyboard' = 'yes'
    'disk.dataPartition.size' = '6G'
    'hw.camera.back' = 'none'; 'hw.camera.front' = 'none'; 'hw.audioInput' = 'no'; 'hw.gps' = 'no'
    'showDeviceFrame' = 'no'; 'skin.dynamic' = 'no'; 'skin.name' = '1600x900'; 'skin.path' = '_no_skin'
    'fastboot.forceFastBoot' = 'yes'
}
$lines = [System.Collections.Generic.List[string]](Get-Content $cfg)
foreach ($k in $settings.Keys) {
    $idx = -1
    for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i] -match "^\s*$([regex]::Escape($k))\s*=") { $idx = $i; break } }
    $line = "$k=$($settings[$k])"
    if ($idx -ge 0) { $lines[$idx] = $line } else { $lines.Add($line) }
}
Set-Content -Path $cfg -Value $lines -Encoding ASCII
} else { Write-Host 'Configuracao atual mantida.' }

# 8. Ambiente Python
Step 'Preparando ambiente Python'
Push-Location $here
$venvOk = $false
if (Test-Path .\.venv\Scripts\python.exe) {
    & .\.venv\Scripts\python.exe -c "import PySide6, grpc, psutil" 2>$null
    if ($LASTEXITCODE -eq 0) { $venvOk = $true }
}
if ($venvOk) {
    Write-Host 'Ambiente Python ja esta pronto (so conferindo as bibliotecas).' -ForegroundColor Green
} else {
    Write-Host 'Criando ambiente Python (pode levar alguns minutos)...'
    Remove-Item .venv -Recurse -Force -ErrorAction SilentlyContinue
    & $pyExe -m venv .venv
    Check 'Criacao do ambiente Python'
    & .\.venv\Scripts\python.exe -m pip install --upgrade pip
}
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
Check 'Instalacao das bibliotecas Python'

# 9. Gerar o cliente gRPC a partir do proto do emulador
Step 'Gerando cliente gRPC'
$protoDir = Join-Path $sdk 'emulator\lib'
$wkt = & .\.venv\Scripts\python.exe -c "import grpc_tools,os;print(os.path.join(os.path.dirname(grpc_tools.__file__),'_proto'))"
& .\.venv\Scripts\python.exe -m grpc_tools.protoc -I $protoDir -I $wkt --python_out=mh_emulator\proto --grpc_python_out=mh_emulator\proto (Join-Path $protoDir 'emulator_controller.proto')
Check 'Geracao do cliente gRPC'
Pop-Location

Stop-Transcript | Out-Null
Step 'Pronto!'
if ($needReboot) {
    Write-Host 'REINICIE o PC antes de abrir o MH Play.' -ForegroundColor Yellow
} else {
    Write-Host 'Abra o INICIAR.bat.' -ForegroundColor Green
}
