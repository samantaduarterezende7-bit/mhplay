# MH Play v0.10

![logo](assets/logo.png)

Emulador Android próprio pra Free Fire, com mira em **raw input**: o movimento vem cru do sensor do mouse, sem a aceleração do Windows.

**Base:** emulador oficial do Android (open source, QEMU) com Android 11 Play Store x86_64, que já roda jogos ARM.
**Código do MH:** a janela, a barra lateral, o motor de mapeamento, a mira, as macros e as configurações.

## Instalar (uma vez)
1. Feche o MSI App Player.
2. Clique duas vezes em **INSTALAR.bat** e aceite o pedido de administrador. Ele baixa uns 2 a 3 GB:
   - Java 17
   - Python
   - Android SDK
   - imagem Android 11

   No final, ele cria o dispositivo **MH_FF** já otimizado pro seu PC: 6 núcleos, 8 GB, GPU NVIDIA, 1600x900 e 240 DPI.
3. Se ele pedir, **reinicie o PC** (pra ativar o Windows Hypervisor Platform).

## Usar
- Abra o **INICIAR.bat**. Na primeira vez o Android demora 1 a 2 minutos pra ligar.
- Entre na Play Store com uma conta Google e instale o Free Fire. Ou use o botão **APK**.
- O seu layout de teclas (`keymaps/freefire.cfg`) já carrega sozinho.

| Tecla | Função |
|---|---|
| `'` (ao lado do 1) | liga/desliga a mira |
| Esc | sai da mira |
| Clique esquerdo | atira (com a mira ligada) |
| WASD | anda |
| F9 | liga/desliga o mapeamento (pra digitar no chat) |
| F11 | tela cheia |

- Velocidade da mira: ☰ Configurações → **Sensibilidade do mouse X** (horizontal) e **Y** (vertical).
- Pra trocar o layout: botão 📂 (aceita .cfg exportado do App Player).

## Se der problema
- Rode o **INICIAR_DEBUG.bat**. A janela preta mostra o erro.
- Os logs ficam em `%LOCALAPPDATA%\MHEmulator\logs\` (`mh.log` e `emulator.log`). Mande eles pra correção.
- Se a tela do Android ficar preta dentro da janela, desmarque "Tela do Android dentro da janela do MH" nas Configurações.

## Importante
Teste primeiro com uma **conta secundária** do Free Fire. Emulador novo pode ser analisado pelo anti-cheat da Garena.

## Seus dados ficam salvos
Apps, conta Google, Free Fire e configurações ficam em `%LOCALAPPDATA%\MHEmulator`, fora desta pasta.
Atualizar ou reinstalar o MH Play **não apaga nada**.

## Fechar tudo
Fechar a janela do MH Play desliga o Android e todos os processos dele.
Se algum dia travar, rode o **FECHAR_TUDO.bat**.

## Android 13 (recomendado pro Free Fire)
Rode o **INSTALAR_ANDROID13.bat**: ele baixa o Android 13 (~3 GB) e cria um segundo Android, sem apagar o 11.
Pra trocar entre eles: Configurações > Versão do Android.
