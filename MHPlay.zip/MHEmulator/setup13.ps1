# MH Play - instala o Android 13 (segundo Android, NAO apaga o Android 11)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = Join-Path $env:LOCALAPPDATA 'MHEmulator'
$sdk  = Join-Path $root 'sdk'
$avdHome = Join-Path $root 'avd'
$settingsFile = Join-Path $root 'settings.json'
$avdName = 'MH_FF13'
$image = 'system-images;android-33;google_apis_playstore;x86_64'
Start-Transcript -Path (Join-Path $root 'logs\instalacao13.log') -Force | Out-Null

trap {
    Write-Host "`nERRO: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Mande este arquivo: $root\logs\instalacao13.log" -ForegroundColor Yellow
    Stop-Transcript | Out-Null
    exit 1
}
function Step($t) { Write-Host "`n==> $t" -ForegroundColor Cyan }
function Check($what) { if ($LASTEXITCODE -ne 0) { throw "$what falhou (codigo $LASTEXITCODE)" } }

# respeita o local escolhido em Configuracoes > Dados do Android
$st = $null
try { $st = Get-Content $settingsFile -Raw -ErrorAction Stop | ConvertFrom-Json } catch {}
if ($st -and $st.avd_home -and (Test-Path $st.avd_home)) { $avdHome = $st.avd_home }
New-Item -ItemType Directory -Force -Path $avdHome | Out-Null

$jdk = Get-ChildItem 'C:\Program Files\Eclipse Adoptium' -Directory -Filter 'jdk-17*' -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $jdk) { throw 'Java 17 nao encontrado. Rode o INSTALAR.bat primeiro.' }
$env:JAVA_HOME = $jdk.FullName
$env:Path = "$($jdk.FullName)\bin;$env:Path"
$env:ANDROID_SDK_ROOT = $sdk; $env:ANDROID_HOME = $sdk; $env:ANDROID_AVD_HOME = $avdHome
$sm = Join-Path $sdk 'cmdline-tools\latest\bin\sdkmanager.bat'
$avdm = Join-Path $sdk 'cmdline-tools\latest\bin\avdmanager.bat'
if (-not (Test-Path $sm)) { throw 'Android SDK nao encontrado. Rode o INSTALAR.bat primeiro.' }

$drive = (Get-Item $avdHome).PSDrive
$freeGB = [math]::Round($drive.Free / 1GB, 1)
Write-Host "Espaco livre no disco $($drive.Name): $freeGB GB"
if ($freeGB -lt 30) { throw "Precisa de pelo menos 30 GB livres no disco $($drive.Name) (tem $freeGB GB)." }

Step 'Baixando o Android 13 (uns 3 GB, pode demorar)'
(1..40 | ForEach-Object { 'y' }) | & $sm --sdk_root=$sdk --licenses | Out-Null
& $sm --sdk_root=$sdk 'emulator' $image
Check 'Download do Android 13'

Step 'Criando o Android 13 do MH Play'
$cfg = Join-Path $avdHome "$avdName.avd\config.ini"
if (Test-Path $cfg) {
    Write-Host 'O Android 13 ja existe: mantendo seus apps e contas.' -ForegroundColor Green
} else {
    'no' | & $avdm create avd -n $avdName -k $image -d 'pixel_4'
    Check 'Criacao do Android 13'
    $settings = [ordered]@{
        'hw.cpu.ncore' = '6'; 'hw.ramSize' = '8192'; 'vm.heapSize' = '576'
        'hw.gpu.enabled' = 'yes'; 'hw.gpu.mode' = 'host'
        'hw.lcd.width' = '1600'; 'hw.lcd.height' = '900'; 'hw.lcd.density' = '240'; 'hw.lcd.vsync' = '60'
        'hw.initialOrientation' = 'landscape'; 'hw.keyboard' = 'yes'
        'disk.dataPartition.size' = '24G'
        'hw.camera.back' = 'none'; 'hw.camera.front' = 'none'; 'hw.audioInput' = 'no'; 'hw.gps' = 'no'
        'showDeviceFrame' = 'no'; 'skin.dynamic' = 'no'; 'skin.name' = '1600x900'; 'skin.path' = '_no_skin'
        'fastboot.forceFastBoot' = 'yes'
    }
    $lines = [System.Collections.Generic.List[string]](Get-Content $cfg)
    foreach ($k in $settings.Keys) {
        $idx = -1
        for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i] -match "^\s*$([regex]::Escape($k))\s*=") { $idx = $i; break } }
        $line = "$k=$($settings[$k])"
        if ($idx -ge 0) { $lines[$idx] = $line } else { $lines.Add($line) }
    }
    Set-Content -Path $cfg -Value $lines -Encoding ASCII
}

Step 'Deixando o Android 13 como padrao no MH Play'
if (-not $st) { $st = [pscustomobject]@{} }
$st | Add-Member -NotePropertyName 'avd' -NotePropertyValue $avdName -Force
[IO.File]::WriteAllText($settingsFile, ($st | ConvertTo-Json -Depth 5), (New-Object System.Text.UTF8Encoding($false)))

Stop-Transcript | Out-Null
Step 'Pronto! Abra o MH Play. A primeira vez do Android 13 leva 1-2 minutos.'
Write-Host 'Pra voltar pro Android 11: MH Play > Configuracoes > Versao do Android.' -ForegroundColor Green
